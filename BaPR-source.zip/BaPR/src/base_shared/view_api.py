"""Label-preserving perturbations; no labels are used to choose a view."""
import torch.nn.functional as F
from core import second_view

def view_order(mode,step,seed):
 if step<1:raise ValueError('positive step required')
 if mode=='repeat':return list(range(8))
 if mode=='position_only':
  shift=(step-1)%3+1
  return [base+(i+shift)%4 for base in [0,4] for i in range(4)]
 if mode=='context_change':return second_view(list(range(8)),seed*10000+step,'dual')
 raise ValueError('unknown view mode')

def view_ce(logits,labels,order):
 if sorted(order)!=list(range(8)) or tuple(logits.shape)!=(8,10) or tuple(labels.shape)!=(8,):raise ValueError('invalid view shape or permutation')
 return F.cross_entropy(logits,labels[order])/2
