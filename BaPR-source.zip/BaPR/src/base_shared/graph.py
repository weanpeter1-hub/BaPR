"""Train-only bundle co-occurrence, leave query bundle out of every statistic."""
from collections import defaultdict
import math
import torch

class BundleGraph:
    def __init__(self,bundles,padding):
        self.padding=padding;self.bundles={};self.postings=defaultdict(set)
        for bid,items in bundles:
            bid=int(bid)
            if bid in self.bundles:raise ValueError('duplicate bundle')
            valid={int(i) for i in items if 0<=int(i)<padding}
            self.bundles[bid]=valid
            for item in valid:self.postings[item].add(bid)

    @classmethod
    def read(cls,path,padding):
        rows=[]
        for line in open(path):
            ids=[int(x.strip()) for x in line.strip().split(',') if x.strip()]
            if ids:rows.append((ids[0],ids[1:]))
        return cls(rows,padding)

    def features(self,public_rows):
        output=[]
        for row in public_rows:
            bid=int(row[0]);ctx=sorted({int(x) for x in row[1] if 0<=int(x)<self.padding})
            total=max(1,len(self.bundles)-int(bid in self.bundles));values=[]
            for candidate in row[3]:
                candidate=int(candidate);cp=self.postings.get(candidate,set())-{bid};cf=len(cp)
                pairs=[];covered=0
                for item in ctx:
                    if item==candidate:continue
                    ip=self.postings.get(item,set())-{bid};freq=len(ip);co=len(cp&ip);covered+=int(freq>0)
                    pairs.append([math.log1p(co),co/math.sqrt(max(1,cf*freq)),co/max(1,freq),
                        max(0.,math.log(co*total/(cf*freq))) if co and cf and freq else 0.,float(co>0)])
                aggregate=[]
                for k in range(5):
                    col=[x[k] for x in pairs] or [0.]
                    aggregate.extend([sum(col)/len(col),max(col),min(col)])
                values.append([math.log1p(cf),covered/max(1,len(pairs))]+aggregate)
            output.append(values)
        return torch.tensor(output,dtype=torch.float32)
