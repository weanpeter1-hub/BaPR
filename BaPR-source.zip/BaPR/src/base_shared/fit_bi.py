"""LightGCN BI features trained from scratch on the filtered original graph.

Equations follow the authors' LightGCN implementation (normal initialization,
mean of ego/propagated embeddings, BPR + ego-embedding L2):
https://github.com/gusye1234/LightGCN-PyTorch/blob/master/code/model.py
This is NOT claimed to reconstruct the unknown supplied-feature training recipe.
"""
import argparse
import json
import time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from core import atomic
from filtered_data import read_bundles,normalized_adjacency

@torch.no_grad()
def cosine_hits(features,rows,padding):
    features=F.normalize(features,dim=-1)
    scores=[]
    for r in rows:
        ctx=[int(i) for i in r[1] if int(i)!=padding]
        candidates=torch.as_tensor(r[3],device=features.device).long()
        scores.append((features[candidates]@features[ctx].T).mean(-1))
    z=torch.stack(scores).cpu();y=torch.tensor([int(r[2]) for r in rows])
    return int(z.argmax(-1).eq(y).sum())

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);a=ap.parse_args()
    out=Path(a.out);dest=out/'bi_pretraining';dest.mkdir();torch.set_num_threads(2);torch.manual_seed(42);torch.cuda.manual_seed_all(42)
    dataset=json.loads((out/'data_boundary.json').read_text())['dataset']
    path=out/'data'/dataset;counts=json.loads((path/'count.json').read_text());nb,ni=counts['#B'],counts['#I']
    bundles=read_bundles(path/'bi_train.txt');pairs=torch.tensor([(b,i) for b,items in bundles.items() for i in sorted(items)])
    adj=normalized_adjacency(pairs,nb,ni).to_sparse_csr().cuda()
    embedding=torch.nn.Embedding(nb+ni,64,device='cuda');torch.nn.init.normal_(embedding.weight,std=.1)
    opt=torch.optim.Adam(embedding.parameters(),lr=.001)
    validation=torch.load(out/'manifests/selection.pt',map_location='cpu',weights_only=False)
    rng=np.random.default_rng(42);history=[];best_hits=-1;start=time.monotonic()
    def propagated():return (embedding.weight+torch.sparse.mm(adj,embedding.weight))/2
    def record(epoch):
        nonlocal best_hits
        with torch.no_grad(): features=propagated()[nb:].detach()
        hits=cosine_hits(features,validation,ni)
        ck=dest/f'epoch{epoch:03d}.pt'
        torch.save(dict(embedding=embedding.state_dict(),optimizer=opt.state_dict(),epoch=epoch,seed=42,
            features=features.cpu(),rng=rng.bit_generator.state,selection='validation'),ck)
        rec=dict(epoch=epoch,validation_hits=hits,checkpoint=str(ck),elapsed_seconds=time.monotonic()-start)
        history.append(rec);atomic(dest/'history.json',history)
        if hits>best_hits:
            best_hits=hits;torch.save(features.cpu(),path/f'{dataset}_LightGCN_bi_feature.pt');atomic(dest/'selection.json',rec)
        print(json.dumps(dict(phase='bi_validation',**rec)),flush=True)
    atomic(dest/'protocol.json',dict(dim=64,layers=1,lr=.001,l2=1e-5,batch=2048,epochs=200,seed=42,
        edges=len(pairs),graph_source=str(path/'bi_train.txt'),reserved_bundle_edges=0,
        fitting='BPR on retained graph only',selection='validation cosine completion; ties earlier',
        validation_checkpoints=list(range(0,201,10)),original_feature_weights_loaded=False))
    record(0)
    for epoch in range(1,201):
        permutation=rng.permutation(len(pairs));losses=[]
        for offset in range(0,len(pairs),2048):
            batch=pairs[permutation[offset:offset+2048]];left=batch[:,0].numpy();pos=batch[:,1].numpy()
            neg=rng.integers(ni,size=len(batch))
            for j,b in enumerate(left):
                while int(neg[j]) in bundles[int(b)]:neg[j]=rng.integers(ni)
            u=batch[:,0].cuda();p=batch[:,1].cuda()+nb;n=torch.as_tensor(neg,device='cuda')+nb
            propagated_all=propagated();z=(propagated_all[u]*(propagated_all[n]-propagated_all[p])).sum(-1)
            reg=(embedding(u).square().sum()+embedding(p).square().sum()+embedding(n).square().sum())/(2*len(u))
            loss=F.softplus(z).mean()+1e-5*reg
            opt.zero_grad(set_to_none=True);loss.backward();opt.step();losses.append(float(loss.detach()))
        progress=dict(phase='bi_training',epoch=epoch,epochs=200,loss=sum(losses)/len(losses),elapsed_seconds=time.monotonic()-start)
        atomic(out/'progress.json',progress);print(json.dumps(progress),flush=True)
        if epoch%10==0:record(epoch)
    selected=json.loads((dest/'selection.json').read_text())
    atomic(dest/'complete.json',dict(status='complete',selected=selected,elapsed_seconds=time.monotonic()-start))

if __name__=='__main__':main()
