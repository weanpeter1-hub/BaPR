"""Historical adaptation, matched repeat/dual, and bundle-disjoint correction."""
import argparse
import gc
import json
import random
import sys
import time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
from peft import set_peft_model_state_dict
from safetensors.torch import load_file
from filtered_data import configuration,load_data
from core import atomic,public_rows,row_identities,metrics
from graph import BundleGraph
from candidate_features import candidate_features
from view_api import view_order
from heads import train_one,apply_selected,describe
from data_roles import evaluation_windows

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'legacy'))
from model_spotify_eval import BundleMLLM
from batch_rank_s3 import PromptBuilder
from utils_spotify_repro import setup_seeds

def restore(model,path):
    path=Path(path);set_peft_model_state_dict(model.llama_model,load_file(str(path/'adapter_model.safetensors')))
    for attr,name in [('fusion','fusion.bin'),('projector','projector_model_fuse.bin'),('prompt_token','prompt_token.bin')]:
        getattr(model,attr).load_state_dict(torch.load(path/name,map_location='cpu',weights_only=True))
    model.eval()

def save(model,path,record,opt=None):
    path.mkdir(parents=True)
    model.llama_model.save_pretrained(path,safe_serialization=True,save_embedding_layers=False)
    for attr,name in [('fusion','fusion.bin'),('projector','projector_model_fuse.bin'),('prompt_token','prompt_token.bin')]:
        torch.save({k:v.detach().cpu() for k,v in getattr(model,attr).state_dict().items()},path/name)
    torch.save(dict(optimizer=opt.state_dict() if opt else None,python=random.getstate(),numpy=np.random.get_state(),
        torch=torch.get_rng_state(),cuda=torch.cuda.get_rng_state_all()),path/'training_state.pt')
    atomic(path/'model_record.json',record)

@torch.no_grad()
def evaluate(model,rows,size,progress,tag,feature=False):
    model.eval();builder=PromptBuilder(model);all_z=[];all_f=[];useful=padded=0
    for offset,stop,keep in evaluation_windows(len(rows)):
        batch=public_rows(rows[offset:stop]);groups=[batch[i:i+size] for i in range(0,len(batch),size)]
        z,u,p=builder.score(groups,gradient=False);z=z.reshape(len(batch),10)
        all_z.append(z[keep:].cpu());useful+=u;padded+=p
        if feature:all_f.append(candidate_features(model,batch,z)[keep:])
        if offset%512==0:progress(phase='evaluate',tag=tag,rows=offset+len(batch),total=len(rows))
    z=torch.cat(all_z);y=torch.tensor([int(r[2]) for r in rows])
    result=dict(logits=z,labels=y,hits=int(z.argmax(-1).eq(y).sum()),ce=float(F.cross_entropy(z,y)),
        samples=len(rows),input_positions=useful,padded_positions=padded)
    if feature:result['features']=torch.cat(all_f)
    return result

def summary(result):return {k:v for k,v in result.items() if not torch.is_tensor(v)}

def adapt(model,out,validation,parent,progress):
    dest=out/'batch_adaptation';dest.mkdir();setup_seeds(42)
    model.requires_grad_(False)
    for n,p in model.llama_model.named_parameters():
        if 'lora_' in n:p.requires_grad_(True)
    opt=torch.optim.AdamW([p for p in model.parameters() if p.requires_grad],lr=5e-5)
    history=[];stale=0;best_key=(-1,-1)
    def record(epoch):
        nonlocal best_key,stale
        b4=evaluate(model,validation,4,progress,f'batch/e{epoch}/B4')
        b1=evaluate(model,validation,1,progress,f'batch/e{epoch}/B1')
        ck=dest/f'epoch{epoch:03d}';rec=dict(epoch=epoch,checkpoint=str(ck),parent=str(parent),
            validation=summary(b4),validation_B1=summary(b1),selection='validation',seed=42)
        save(model,ck,rec,opt);torch.save(b4,ck/'validation_B4.pt');history.append(rec);atomic(dest/'history.json',history)
        key=(b4['hits'],b1['hits'])
        if key>best_key:best_key=key;stale=0;atomic(dest/'selection.json',rec)
        else:stale+=1
        progress(phase='batch_validation',epoch=epoch,B4_hits=b4['hits'],B1_hits=b1['hits'],stale=stale)
    atomic(dest/'protocol.json',dict(parent=str(parent),lr=5e-5,weight_decay=.01,epochs_min=12,epochs_max=30,
        patience=6,mixed_prompt_rows={'B1':344,'B2':340,'B4':340},physical_questions=8,
        trainable='q/v LoRA only',soft_prompt=True,del_sp=False,seed=42,
        epoch_manifests='actual historical Sep15 manifests copied unchanged',selection='validation B4 then B1'))
    record(0);builder=PromptBuilder(model)
    for epoch in range(1,31):
        rows=torch.load(out/f'manifests/train_epoch_{epoch:02d}.pt',map_location='cpu',weights_only=False)
        random.Random(8400+epoch).shuffle(rows)
        steps=[]
        for size,part in [(1,rows[:344]),(2,rows[344:684]),(4,rows[684:])]:
            groups=[part[i:i+size] for i in range(0,len(part),size)];per=8//size
            steps.extend([groups[i:i+per] for i in range(0,len(groups),per)])
        random.Random(9400+epoch).shuffle(steps);model.train();started=time.monotonic()
        for step,groups in enumerate(steps,1):
            z,_,_=builder.score([public_rows(g) for g in groups],gradient=True)
            y=torch.tensor([int(r[2]) for g in groups for r in g],device='cuda')
            loss=F.cross_entropy(z.reshape(-1,10),y)
            opt.zero_grad(set_to_none=True);loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.);opt.step()
            if step==1 or step%16==0:progress(phase='batch_training',epoch=epoch,step=step,total_steps=len(steps),
                loss=float(loss.detach()),seconds_per_step=(time.monotonic()-started)/step)
        record(epoch)
        if epoch>=12 and stale>=6:break
    selected=json.loads((dest/'selection.json').read_text());restore(model,selected['checkpoint'])
    atomic(dest/'complete.json',dict(status='complete',selected=selected,epochs=epoch))
    return selected

def dual(model,out,validation,parent,progress,mode,seed=20261028,initial_validation=None):
    dest=out/mode;dest.mkdir();restore(model,parent)
    model.requires_grad_(False)
    params=[]
    for n,p in model.llama_model.named_parameters():
        if 'lora_' in n:p.requires_grad_(True);params.append(p)
    model.llama_model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={'use_reentrant':False})
    model.llama_model.config.use_cache=False
    opt=torch.optim.AdamW(params,lr=2e-6,weight_decay=.01);builder=PromptBuilder(model);history=[]
    def record(step):
        result=initial_validation if step==0 and initial_validation is not None else evaluate(model,validation,4,progress,f'{mode}/step{step}')
        ck=dest/f'checkpoint-{step}';rec=dict(step=step,checkpoint=str(ck),parent=str(parent),seed=seed,mode=mode,
            validation=summary(result),selection='validation')
        save(model,ck,rec,opt);torch.save(result,ck/'validation.pt');history.append(rec);atomic(dest/'history.json',history)
    atomic(dest/'protocol.json',dict(parent=str(parent),seed=seed,lr=2e-6,steps=64,weights=[.5,.5],
        view='two original views' if mode=='repeat_ce' else 'odd position-only, even position+neighbor',selection='validation hits then CE then earlier step',
        source_questions='historical original train_epoch01',checkpoints=[0,32,64]))
    record(0)
    rows=torch.load(out/'manifests/train1024.pt',map_location='cpu',weights_only=False)
    order=list(range(len(rows)));random.Random(seed).shuffle(order)
    for step in range(1,65):
        batch=[rows[i] for i in order[(step-1)*8:step*8]];pub=public_rows(batch)
        y=torch.tensor([int(r[2]) for r in batch],device='cuda')
        permutation=view_order('repeat' if mode=='repeat_ce' else ('position_only' if step%2 else 'context_change'),step,seed)
        setup_seeds((seed*10000+step)%(2**32));model.eval();model.llama_model.train();opt.zero_grad(set_to_none=True)
        value=0.
        for perm in [list(range(8)),permutation]:
            view=[pub[i] for i in perm]
            z,_,_=builder.score([view[:4],view[4:]],gradient=True)
            loss=.5*F.cross_entropy(z.reshape(8,10),y[perm]);loss.backward();value+=float(loss.detach())
        torch.nn.utils.clip_grad_norm_(params,1.);opt.step()
        if step==1 or step%16==0:progress(phase='dual_training',mode=mode,step=step,total_steps=64,loss=value)
        if step in [32,64]:record(step)
    selected=max(history,key=lambda r:(r['validation']['hits'],-r['validation']['ce'],-r['step']))
    atomic(dest/'selection.json',selected);atomic(dest/'complete.json',dict(status='complete',selected=selected))
    restore(model,selected['checkpoint']);return selected

