"""Matched Repeat/Dual ablation on a fixed heldout-relation parent."""
import argparse
import json
from pathlib import Path
import torch
from batch_and_head import (configuration, load_data, BundleMLLM, setup_seeds,
    restore, dual, evaluate, BundleGraph, public_rows, row_identities,
    train_one, apply_selected, metrics, describe, atomic)
from system_selection import MODES, HEAD_SEEDS, choose_system


def compact(cache):
    return {k:v for k,v in cache.items() if not torch.is_tensor(v) and k!='identities'}


def prediction_comparison(a,b,y):
    repairs=int(((a!=y)&(b==y)).sum());damages=int(((a==y)&(b!=y)).sum())
    return dict(samples=len(y),repairs=repairs,damages=damages,
        gain_hits=repairs-damages,gain_pp=100*(repairs-damages)/len(y))


def fit_case(model, graph, correction, validation, record, dest, progress):
    dest.mkdir();restore(model,record['checkpoint']);model.eval().requires_grad_(False)
    caches={}
    for split,rows in [('train',correction),('validation',validation)]:
        cache=evaluate(model,rows,4,progress,str(dest.name)+':'+split,feature=True)
        cache['graph']=graph.features(public_rows(rows));cache['identities']=row_identities(rows)
        torch.save(cache,dest/f'{split}.pt');caches[split]=cache
    heads=[train_one(caches['train'],caches['validation'],seed,dest/f'headseed{seed}',
        record['checkpoint'],'reserved_original_training2048',progress) for seed in HEAD_SEEDS]
    result=dict(source=record,heads=heads,case_dir=str(dest),correction_base=compact(caches['train']))
    atomic(dest/'fit_complete.json',result)
    return result


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);ap.add_argument('--source',required=True)
    ap.add_argument('--seed',type=int,default=20261028);ap.add_argument('--phase',choices=['parent','fit','report'],required=True)
    args=ap.parse_args();root=Path(args.out);source=Path(args.source)
    out=root if args.phase=='parent' else root/f'llm_seed{args.seed}'
    torch.set_num_threads(2)
    def progress(**values):
        rec=dict(llm_seed=args.seed,run_phase=args.phase,**values)
        atomic(root/'progress.json',rec)
        if out!=root:atomic(out/'progress.json',rec)
        print(json.dumps(rec),flush=True)
    parent=json.loads((source/'batch_adaptation/selection.json').read_text())
    setup_seeds(42)
    conf=configuration(Path.cwd(),out,'text+mm',parent['checkpoint']);conf['del_sp']=False
    conf.update(training_stage='joint',fast_candidate_inference=True,disable_candidate_logit_pruning=False,
        uncertainty_gate_power=0.,compatibility_temperature=.1,base_margin=.2,
        hardness_margin_scale=.3,text_format='artist_track_album')
    progress(phase='loading')
    data=load_data(conf)
    model=BundleMLLM(conf,data.graphs,data.features,data.item_info,is_training=True).to(conf['device'])
    model.option_token_ids=[model.tokenizer(chr(65+i),add_special_tokens=False).input_ids[-1] for i in range(10)]
    graph=BundleGraph.read(out/'data'/conf['dataset']/'bi_train.txt',data.num_items)

    if args.phase in ['parent','fit']:
        validation=torch.load(out/'manifests/selection.pt',map_location='cpu',weights_only=False)
        correction=torch.load(out/'manifests/correction.pt',map_location='cpu',weights_only=False)
        if args.phase=='parent':
            record=dict(step=0,checkpoint=parent['checkpoint'],parent=parent['checkpoint'],
                seed=42,validation=parent['validation'],selection='existing heldout parent')
            fit_case(model,graph,correction,validation,record,root/'parent_case',progress)
            progress(phase='parent_fit_complete');return
        shared=json.loads((root/'parent_case/fit_complete.json').read_text())
        initial={k:v for k,v in torch.load(root/'parent_case/validation.pt',map_location='cpu',weights_only=False).items()
            if k not in ['features','graph','identities']}
        raw_best={mode:dual(model,out,validation,parent['checkpoint'],progress,mode,
            seed=args.seed,initial_validation=initial) for mode in MODES}
        branches={}
        for mode in MODES:
            history=json.loads((out/mode/'history.json').read_text());cases=[shared]
            for record in history:
                if record['step']==0:continue
                cases.append(fit_case(model,graph,correction,validation,record,
                    out/f'{mode}_case{record["step"]}',progress))
            branches[mode]=choose_system(cases)
            atomic(out/f'{mode}_all_cases.json',dict(cases=cases,raw_best=raw_best[mode],selected=branches[mode]))
        locked=dict(llm_seed=args.seed,parent=parent,branches=branches,raw_selected=raw_best,
            correction_training_rows=len(correction),selection_rows=len(validation),head_seeds=HEAD_SEEDS,
            selection='original validation only; full-system mean across three heads selects LLM step',
            primary_comparison='mixed_dual+H minus matched repeat_ce+H')
        atomic(out/'locked_selection.json',locked)
        atomic(out/'fit_complete.json',dict(status='complete',llm_seed=args.seed))
        progress(phase='fit_complete');return

    # Every pair has been locked by the controller before any test is loaded.
    locked=json.loads((root/'locked_selection.json').read_text())['new_llm_seeds'][str(args.seed)]
    test=torch.load(out/'manifests/test2048.pt',map_location='cpu',weights_only=False)
    all_test={};bases={};selected_predictions={}
    for mode,record in locked['branches'].items():
        dest=Path(record['case_dir']);cachefile=dest/'test.pt'
        if cachefile.exists():
            cache=torch.load(cachefile,map_location='cpu',weights_only=False)
        else:
            restore(model,record['source']['checkpoint']);model.eval().requires_grad_(False)
            cache=evaluate(model,test,4,progress,mode+':final_test',feature=True)
            cache['graph']=graph.features(public_rows(test));cache['identities']=row_identities(test)
            torch.save(cache,cachefile)
        results=[];bases[mode]=cache
        for head in record['heads']:
            scorefile=dest/f'test_seed{head["seed"]}.pt'
            if scorefile.exists():
                saved=torch.load(scorefile,map_location='cpu',weights_only=False)
                scores,pred=saved['scores'],saved['predictions']
            else:
                scores,pred=apply_selected(head,cache)
                torch.save(dict(scores=scores,predictions=pred),scorefile)
            results.append(dict(head,test=metrics(cache['logits'],cache['labels'],pred)))
            if head['seed']==record['head']['seed']:selected_predictions[mode]=pred
        all_test[mode]=dict(source=record['source'],base_test=compact(cache),all_heads=results,
            summary=describe(results,'test'),selected=next(x for x in results if x['seed']==record['head']['seed']))
        final=out/('final_'+mode);final.mkdir()
        for name in ['adapter_config.json','adapter_model.safetensors','fusion.bin','projector_model_fuse.bin','prompt_token.bin']:
            (final/name).symlink_to(Path(record['source']['checkpoint'])/name)
        (final/'relation_head.pt').symlink_to(Path(record['head']['checkpoint']))
        atomic(final/'inference_config.json',dict(llm_seed=args.seed,source=record['source'],head=record['head'],selection=locked['selection']))
    y=bases['repeat_ce']['labels']
    atomic(out/'complete.json',dict(status='complete',llm_seed=args.seed,locked=locked,branches=all_test,
        raw_dual_vs_repeat=prediction_comparison(bases['repeat_ce']['logits'].argmax(-1),bases['mixed_dual']['logits'].argmax(-1),y),
        corrected_dual_vs_repeat=prediction_comparison(selected_predictions['repeat_ce'],selected_predictions['mixed_dual'],y),
        corrected_selected_gain=all_test['mixed_dual']['selected']['test']['hits']-all_test['repeat_ce']['selected']['test']['hits']))
    progress(phase='report_complete')

if __name__=='__main__':main()
