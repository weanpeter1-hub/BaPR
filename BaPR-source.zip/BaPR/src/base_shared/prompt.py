"""Shared answer slots with trainable multimodal input assembly."""
from contextlib import nullcontext
import torch
from batch_rank_s3 import PromptBuilder

class Builder(PromptBuilder):
    def __init__(self, model, multimodal=True, bridge_grad=False):
        super().__init__(model)
        self.multimodal = multimodal
        self.bridge_grad = bridge_grad
        self.text_tokens = 0

    def text(self, value):
        ids = self.ids(value)
        self.text_tokens += len(ids)
        return self.model._embed_tokens(ids).unsqueeze(0)

    def pack(self, group):
        self.text_tokens += 1
        pieces = [self.model.bos_embeds.unsqueeze(0), self.text(self.instruction+'\n')]
        context = nullcontext() if self.bridge_grad else torch.no_grad()
        soft = self.model.prompt_token.weight if self.bridge_grad else self.model.prompt_token.weight.detach()
        with context:
            for slot, (_, indices, _, candidates) in enumerate(group, 1):
                items = [int(i) for i in indices if int(i) != self.model.num_item]
                cans = [int(i) for i in candidates]
                if self.multimodal:
                    fused = self.model.fusion(torch.tensor([items+cans], device=self.model.device), self.model.prompt_token)
                    projected = self.model.projector(fused)[0]
                pieces.append(self.text(f'\nQuestion {slot}\n{self.context_label}:\n'))
                for j, item in enumerate(items):
                    pieces.append(self.text(f'{j+1}. {self.model._get_caption(item)} '))
                    if self.multimodal:
                        if not self.model.conf['del_sp']:pieces.append(soft.view(1,1,-1))
                        pieces.append(projected[j].view(1,1,-1))
                    pieces.append(self.text(';\n'))
                pieces.append(self.text('Candidates:\n'))
                for j, item in enumerate(cans):
                    pieces.append(self.text(f'{chr(65+j)}. {self.model._get_caption(item)} '))
                    if self.multimodal:
                        if not self.model.conf['del_sp']:pieces.append(soft.view(1,1,-1))
                        pieces.append(projected[len(items)+j].view(1,1,-1))
                    pieces.append(self.text(';\n'))
        pieces.append(self.text('\nIndependent answer slots:\n'))
        positions=[]; length=sum(p.shape[1] for p in pieces)
        for slot in range(1,len(group)+1):
            marker=self.text(f'Question {slot}: ');pieces.append(marker);length+=marker.shape[1];positions.append(length-1)
            sep=self.text('|\n');pieces.append(sep);length+=sep.shape[1]
        return torch.cat(pieces,dim=1),positions
