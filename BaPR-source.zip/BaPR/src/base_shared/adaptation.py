import argparse,json
from pathlib import Path
import torch
from batch_and_head import configuration,load_data,BundleMLLM,setup_seeds,adapt,atomic

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);a=ap.parse_args();out=Path(a.out)
    torch.set_num_threads(2);setup_seeds(42)
    def progress(**v):atomic(out/'progress.json',v);print(json.dumps(v),flush=True)
    parent=json.loads((out/'single_multimodal/selection.json').read_text())['checkpoint']
    conf=configuration(Path.cwd(),out,'text+mm',parent);conf['del_sp']=False
    conf.update(training_stage='joint',fast_candidate_inference=True,disable_candidate_logit_pruning=False,
        uncertainty_gate_power=0.,compatibility_temperature=.1,base_margin=.2,hardness_margin_scale=.3,
        text_format='artist_track_album')
    data=load_data(conf);model=BundleMLLM(conf,data.graphs,data.features,data.item_info,is_training=True).to(conf['device'])
    model.option_token_ids=[model.tokenizer(chr(65+i),add_special_tokens=False).input_ids[-1] for i in range(10)]
    validation=torch.load(out/'manifests/selection.pt',map_location='cpu',weights_only=False)
    adapt(model,out,validation,parent,progress)
