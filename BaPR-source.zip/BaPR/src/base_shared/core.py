"""Common, testable arithmetic; labels are never accepted by feature functions."""
import hashlib
import json
import os
import random
from pathlib import Path
import torch
from torch import nn
import torch.nn.functional as F

SEEDS = [20261028, 20261029, 20261030]

def atomic(path, value):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(value,indent=2,ensure_ascii=False));os.replace(tmp,path)

def file_hash(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

class PoisonLabel:
    def __int__(self):raise RuntimeError('answer accessed in public input')
    def __index__(self):raise RuntimeError('answer accessed in public input')

def public_rows(rows):return [(r[0],r[1],PoisonLabel(),r[3]) for r in rows]
def row_identities(rows):return [dict(id=int(r[0]),context=torch.as_tensor(r[1]).tolist(),candidates=torch.as_tensor(r[3]).tolist()) for r in rows]

def second_view(indices, seed, mode):
    if len(indices)!=8:raise ValueError('physical batch must contain8 questions')
    if mode=='repeat':return list(indices)
    if mode!='dual':raise ValueError('invalid view')
    rng=random.Random(seed)
    while True:
        order=list(range(8));rng.shuffle(order)
        if all(i!=j and i%4!=j%4 for i,j in enumerate(order)) and set(order[:4])!=set(range(4)) and set(order[:4])!=set(range(4,8)):break
    return [indices[i] for i in order]

def align_view(values, permutation):return values[torch.argsort(torch.tensor(permutation,device=values.device))]

def head_features(candidate, graph, score, zero_graph=False):
    graph=torch.zeros_like(graph) if zero_graph else graph
    x=torch.cat([candidate,graph],-1)
    winner=score.argmax(-1);ref=x[torch.arange(len(x),device=x.device),winner][:,None,:]
    return torch.cat([x,x-ref,F.one_hot(winner,score.shape[-1]).float()[:,:,None]],-1).detach()

def fit_normalizer(training):
    flat=training.detach().reshape(-1,training.shape[-1])
    if not torch.isfinite(flat).all():raise ValueError('nonfinite training normalizer')
    return flat.mean(0),flat.std(0).clamp_min(1e-4)

class RelationHead(nn.Module):
    def __init__(self,dim=57):
        super().__init__();self.net=nn.Sequential(nn.Linear(dim,64),nn.LayerNorm(64),nn.GELU(),nn.Linear(64,32),nn.GELU(),nn.Linear(32,1))
        nn.init.zeros_(self.net[-1].weight);nn.init.zeros_(self.net[-1].bias)
    def forward(self,x,z):
        delta=self.net(x).squeeze(-1)
        return z.detach()+1.5*torch.tanh(delta-delta.mean(-1,keepdim=True))

def margin(z,y):return z.gather(1,y[:,None]).squeeze(1)-z.masked_fill(F.one_hot(y,z.shape[1]).bool(),-torch.inf).max(-1).values

def head_loss(score,base,y,preserve=True):
    base=base.detach();correct=base.argmax(-1).eq(y);weight=torch.where(correct,1.,3.)
    ce=(F.cross_entropy(score,y,reduction='none')*weight).sum()/weight.sum()
    rank=(F.softplus(.1-margin(score,y))*weight).sum()/weight.sum()
    kl=F.kl_div(score[correct].log_softmax(-1),base[correct].softmax(-1),reduction='batchmean') if correct.any() else score.sum()*0
    keep=F.relu(margin(base,y)[correct].clamp(.05,.5)-margin(score,y)[correct]).mean() if correct.any() else score.sum()*0
    l2=(score-base).square().mean()
    return ce+.2*rank+(.5*kl+.2*keep if preserve else 0)+.02*l2,dict(ce=ce,rank=rank,kl=kl,keep=keep,l2=l2)

def predict(base,score,safety=.1):
    old=base.argmax(-1);new=score.argmax(-1);idx=torch.arange(len(base),device=base.device)
    return torch.where(score[idx,new]-score[idx,old]>safety,new,old)

def metrics(base,labels,pred):
    old=base.argmax(-1);before=old.eq(labels);after=pred.eq(labels)
    return dict(hits=int(after.sum()),hitrate=int(after.sum())/len(labels),base_hits=int(before.sum()),repairs=int((~before&after).sum()),damages=int((before&~after).sum()),changed=int(old.ne(pred).sum()),net_gain=int(after.sum()-before.sum()))

def select_record(records):return max(records,key=lambda r:(r['hits'],-r.get('damages',0),-r.get('step',r.get('epoch',0))))
def complete_status(rc,summary):return rc==0 and summary.get('status')=='complete'

def validate_splits(graph, rows):
    sets={k:{int(r[0]) for r in v} for k,v in rows.items()}
    if not sets['train']<=set(graph.bundles):raise ValueError('train outside original graph')
    if sets['validation']&set(graph.bundles) or sets['test']&set(graph.bundles):raise ValueError('evaluation overlap training graph')
    if any(sets[a]&sets[b] for a,b in [('train','validation'),('train','test'),('validation','test')]):raise ValueError('split overlap')
