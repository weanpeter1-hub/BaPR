import torch
import torch.nn.functional as F

@torch.no_grad()
def candidate_features(model,rows,logits):
 z=logits.detach().float()
 if z.ndim!=2 or len(rows)!=len(z) or not torch.isfinite(z).all():raise ValueError('logits')
 # Tied candidates receive the same rank: no position-dependent tie breaking.
 rank=(z[:,:,None]<z[:,None,:]).float().sum(-1)/max(1,z.shape[1]-1)
 scalar=torch.stack([z-z.mean(-1,keepdim=True),z.softmax(-1),rank],-1).cpu();extra=[]
 for row in rows:
  ctx=[int(x) for x in row[1] if 0<=int(x)<model.num_item];cans=[int(x) for x in row[3]]
  if len(cans)!=z.shape[1] or any(x<0 or x>=model.num_item for x in cans):raise ValueError('candidates')
  cols=[]
  for name in ['text_feature','content_feature','cf_feature','bi_feature']:
   emb=getattr(model.fusion,name);candidate=F.normalize(emb[cans].float(),dim=-1)
   if ctx:
    context=F.normalize(emb[ctx].float(),dim=-1);sim=candidate@context.T
    cols.extend([sim.mean(-1).cpu(),sim.max(-1).values.cpu()])
   else:cols.extend([torch.zeros(len(cans)),torch.zeros(len(cans))])
  extra.append(torch.stack(cols,-1))
 out=torch.cat([scalar,torch.stack(extra)],-1)
 if not torch.isfinite(out).all():raise ValueError('nonfinite features')
 return out

