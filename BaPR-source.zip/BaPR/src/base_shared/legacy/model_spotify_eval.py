import math
import os
from collections import OrderedDict
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
import torch
from peft import (
    LoraConfig,
    get_peft_model,
    prepare_model_for_kbit_training,
    PeftModel,
)
from torch import nn as nn
from torch.nn import functional as F
from transformers import AutoModelForCausalLM, AutoTokenizer

class HierachicalEncoder(nn.Module):
    def __init__(self, conf, raw_graph, features, sp_feature):
        super(HierachicalEncoder, self).__init__()
        self.conf = conf
        device = self.conf["device"]
        self.device = device
        self.num_user = self.conf["num_users"]
        self.num_bundle = self.conf["num_bundles"]
        self.num_item = self.conf["num_items"]
        self.embedding_size = 64
        self.ui_graph, self.bi_graph_train, self.bi_graph_seen = raw_graph
        self.attention_components = conf["components"].split(", ") if conf[
                                                                          "components"] != "" else []

        self.content_feature, self.text_feature, self.cf_feature, self.bi_feature = features
        self.modality_dropout = float(conf.get("modality_dropout", 0.05))

        # MM >>>
        self.content_feature = nn.functional.normalize(
            self.content_feature, dim=-1)
        self.text_feature = nn.functional.normalize(self.text_feature, dim=-1)

        def dense(feature):
            module = nn.Sequential(OrderedDict([
                ('w1', nn.Linear(feature.shape[1], feature.shape[1])),
                ('act1', nn.ReLU()),
                ('w2', nn.Linear(feature.shape[1], 256)),
                ('act2', nn.ReLU()),
                ('w3', nn.Linear(256, 64)),
            ]))

            for m in module:
                init(m)
            return module

        # encoders for media feature
        self.c_encoder = dense(self.content_feature)

        self.multimodal_feature_dim = self.embedding_size
        # MM <<<

        # BI >>>
        self.bi_transformation = nn.Linear(
            self.embedding_size, self.embedding_size)
        init(self.bi_transformation)
        self.multimodal_feature_dim += self.embedding_size
        # BI <<<

        # UI >>>
        self.cf_transformation = nn.Linear(
            self.embedding_size, self.embedding_size)
        init(self.cf_transformation)

        self.multimodal_feature_dim += self.embedding_size
        # UI <<<

        # Multimodal Fusion:
        self.w_q = nn.Linear(self.embedding_size,
                             self.embedding_size, bias=False)
        init(self.w_q)
        self.w_k = nn.Linear(self.embedding_size,
                             self.embedding_size, bias=False)
        init(self.w_k)
        self.w_v = nn.Linear(self.embedding_size,
                             self.embedding_size, bias=False)
        init(self.w_v)
        self.ln = nn.LayerNorm(self.embedding_size, elementwise_affine=False)

        if self.conf["sp_guided"]:
            self.w_q2 = nn.Linear(self.conf["llama_size"],
                                  self.embedding_size, bias=False)
            init(self.w_q2)
            self.w_k2 = nn.Linear(self.embedding_size,
                                  self.embedding_size, bias=False)
            init(self.w_k2)
            self.w_v2 = nn.Linear(self.embedding_size,
                                  self.embedding_size, bias=False)
            init(self.w_v2)
            self.ln2 = nn.LayerNorm(self.embedding_size, elementwise_affine=False)

    def selfAttention(self, features):
        # features: [bs, #modality, d]
        if "layernorm" in self.attention_components:
            features = self.ln(features)
        q = self.w_q(features)
        k = self.w_k(features)
        if "w_v" in self.attention_components:
            v = self.w_v(features)
        else:
            v = features
        # [bs, #modality, #modality]
        attn = q.mul(self.embedding_size ** -0.5) @ k.transpose(-1, -2)
        attn = attn.softmax(dim=-1)

        features = attn @ v  # [bs, #modality, d]
        # average pooling
        y = features.mean(dim=-2)  # [bs, d]

        return features, y

    def selfAttention2(self, sp_feature, features):
        # features: [bs, #modality, d]
        if "layernorm" in self.attention_components:
            features = self.ln2(features)
        q = self.w_q2(sp_feature.view(1, sp_feature.shape[0], -1))  # [1, 1, d]
        k = self.w_k2(features)  # [bs, #m, d]
        if "w_v" in self.attention_components:
            v = self.w_v2(features)
        else:
            v = features
        # [bs, 1, #modality]
        attn = q.mul(self.embedding_size ** -0.5) @ k.transpose(-1, -2)
        attn = attn.softmax(dim=-1)

        # [bs, 1, #modality]
        features = attn @ v  # [bs, 1, d]
        # average pooling

        y = features.mean(dim=-2)

        return y

    def forward(self, seq_modify, sp_feature, all=False):

        # Transform only the queried items; these encoders are pointwise.
        mm_feature = self.c_encoder(self.content_feature[seq_modify])

        modality_features = {"content": mm_feature}
        bi_feature = self.bi_transformation(self.bi_feature[seq_modify])
        modality_features["bi"] = bi_feature

        cf_feature = self.cf_transformation(self.cf_feature[seq_modify])
        modality_features["cf"] = cf_feature

        active_modalities = self.conf.get("active_modalities", ["content", "bi", "cf"])
        unknown = set(active_modalities) - set(modality_features)
        if unknown:
            raise ValueError(f"Unknown active modalities: {sorted(unknown)}")
        if not active_modalities:
            raise ValueError("active_modalities cannot be empty when multimodal input is enabled")
        features = [modality_features[name] for name in active_modalities]

        features = torch.stack(features, dim=-2)  # [bs, n_token, #modality, d]
        bs, n_token, N_modal, d = features.shape

        if self.training and self.modality_dropout > 0:
            keep = torch.rand(
                bs, n_token, N_modal, 1, device=features.device
            ) >= self.modality_dropout
            # Keep at least one modality for every item representation.
            empty = ~keep.any(dim=-2, keepdim=True)
            keep[..., :1, :] |= empty
            features = features * keep.to(features.dtype) / (1.0 - self.modality_dropout)

        # multimodal fusion >>>
        feature_ori, final_feature = self.selfAttention(
            nn.functional.normalize(features.view(-1, N_modal, d), dim=-1))
        final_feature = final_feature.view(bs, n_token, d)
        # multimodal fusion <<<

        if self.conf["sp_guided"]:
            if self.conf["sp_sg"]:
                sp_feature = sp_feature.weight.detach()
            else:
                sp_feature = sp_feature.weight
            final_feature = self.selfAttention2(sp_feature, feature_ori)

        return final_feature


class BundleMLLM(nn.Module):
    def __init__(self, conf, raw_graph, features, item_info, is_training=False):
        super(BundleMLLM, self).__init__()
        self.conf = conf
        self.device = device = conf["device"]
        self.llama_model_path = conf["base_model"]

        self.ui_graph, self.bi_graph_train, self.bi_graph_seen = raw_graph
        self.content_feature, self.text_feature, self.cf_feature, self.bi_feature = features

        self.num_item = self.bi_graph_train.shape[1]

        self.item_info = item_info

        self.dataset_name = conf["dataset"]

        self.caption_key = "title"
        self.text_format = conf.get("text_format", "artist_track_album")

        self.padding_side = "left"

        self.mode = conf["mode"]

        compute_dtype = torch.bfloat16

        bnb_config = BitsAndBytesConfig(
            load_in_8bit=True,
        )

        self.llama_model = AutoModelForCausalLM.from_pretrained(
            self.llama_model_path,
            quantization_config=bnb_config,
            torch_dtype=compute_dtype,
            device_map=self.device,
        )


        self.tokenizer = AutoTokenizer.from_pretrained(self.llama_model_path, padding_side=self.padding_side)
        self.tokenizer.add_bos_token = False
        self.tokenizer.add_prefix_space = False

        self.llama_model.resize_token_embeddings(len(self.tokenizer))

        # Projector
        self.mode = conf["mode"]


        conf["llama_size"] = self.llama_model.config.hidden_size

        if self.conf["soft_prompt"]:
            self.num_pt = 1
            self.prompt_token = nn.Embedding(self.num_pt, self.llama_model.config.hidden_size).to(device)
            init(self.prompt_token)
        else:
            self.prompt_token = None
        self.fusion = HierachicalEncoder(conf, raw_graph, features, self.prompt_token)

        self.feat_dim = self.fusion.embedding_size

        self.projector = nn.Sequential(OrderedDict([
            ('dense1', nn.Linear(self.feat_dim, self.feat_dim * 2)),
            ('act1', nn.GELU()),
            ('output', nn.Linear(self.feat_dim * 2, self.llama_model.config.hidden_size)),
        ])).to(device)
        self.candidate_reranker = nn.Sequential(OrderedDict([
            ("dense1", nn.Linear(self.feat_dim * 4, self.feat_dim * 2)),
            ("act1", nn.GELU()),
            ("dropout", nn.Dropout(float(conf.get("reranker_dropout", 0.1)))),
            ("output", nn.Linear(self.feat_dim * 2, 1)),
        ])).to(device)
        self.candidate_reranker.apply(init)
        nn.init.zeros_(self.candidate_reranker.output.weight)
        nn.init.zeros_(self.candidate_reranker.output.bias)
        self.rerank_gate_logit = nn.Parameter(torch.tensor(-3.0, device=device))

        self.is_training = is_training
        if self.is_training:
            self.llama_model = prepare_model_for_kbit_training(self.llama_model)

        if conf["from_pretrain"]:

            self.lora_config = LoraConfig(
                r=8,
                lora_alpha=16,
                target_modules=["q_proj", "v_proj"],
                lora_dropout=0.05,
                bias="none",
                task_type="CAUSAL_LM",
            )
            adapter_bin = os.path.join(conf["pretrain_model_path"], "adapter_model.bin")
            adapter_safe = os.path.join(conf["pretrain_model_path"], "adapter_model.safetensors")
            adapter_cfg = os.path.join(conf["pretrain_model_path"], "adapter_config.json")

            if os.path.exists(adapter_bin) or os.path.exists(adapter_safe) or os.path.exists(adapter_cfg):
                self.llama_model = PeftModel.from_pretrained(
                    self.llama_model,
                    conf["pretrain_model_path"],
                    is_trainable=conf["train_lora"]
                )
                print(">>>> pretrained llama lora loaded!")
            else:
                self.llama_model = get_peft_model(self.llama_model, self.lora_config)
                print(">>>> initial llama lora loaded!")


            if os.path.exists(f"{conf['pretrain_model_path']}/fusion.bin"):
                self.fusion.load_state_dict(torch.load(f"{conf['pretrain_model_path']}/fusion.bin"))
                print(">>>> fusion.bin loaded!")

            if self.conf["soft_prompt"] and os.path.exists(f"{conf['pretrain_model_path']}/fusion.bin"):
                self.prompt_token.load_state_dict(torch.load(f"{conf['pretrain_model_path']}/prompt_token.bin"))
                print(">>>> prompt_token.bin loaded!")

            if os.path.exists(f"{conf['pretrain_model_path']}/projector_model_fuse.bin"):
                self.projector.load_state_dict(torch.load(f"{conf['pretrain_model_path']}/projector_model_fuse.bin"))
                print(">>>> projector_model_fuse.bin loaded!")
            reranker_path = os.path.join(conf["pretrain_model_path"], "candidate_reranker.bin")
            if os.path.exists(reranker_path):
                reranker_state = torch.load(reranker_path, map_location=device)
                self.candidate_reranker.load_state_dict(reranker_state["state_dict"])
                self.rerank_gate_logit.data.copy_(reranker_state["gate_logit"].to(device))
                print(">>>> candidate_reranker.bin loaded!")
        else:
            self.lora_config = LoraConfig(
                r=8,
                lora_alpha=16,
                target_modules=["q_proj", "v_proj"],
                lora_dropout=0.05,
                bias="none",
                task_type="CAUSAL_LM",
            )
            self.llama_model = get_peft_model(self.llama_model, self.lora_config)

        self.llama_model.model.config.use_cache = False

        # The 7B backbone remains frozen. Only PEFT adapters and the multimodal
        # bridge are optimized during task adaptation.
        for name, parameter in self.llama_model.named_parameters():
            if "lora_" not in name:
                parameter.requires_grad = False
        self.training_stage = conf.get("training_stage", "joint")
        if self.training_stage == "reranker_only":
            for parameter in self.llama_model.parameters():
                parameter.requires_grad = False
            for parameter in self.fusion.parameters():
                parameter.requires_grad = False
            for parameter in self.projector.parameters():
                parameter.requires_grad = False

        self.llama_model.config.pad_token_id = self.tokenizer.pad_token_id = 0  # unk
        self.llama_model.config.bos_token_id = 1
        self.llama_model.config.eos_token_id = 2

        #####################

        self.pad_embeds = self._embed_tokens(torch.tensor([self.tokenizer.pad_token_id], dtype=torch.long))
        self.bos_embeds = self._embed_tokens(torch.tensor([self.tokenizer.bos_token_id], dtype=torch.long))
        self.eos_embeds = self._embed_tokens(torch.tensor([self.tokenizer.eos_token_id], dtype=torch.long))


        #####################
        self._keys_to_ignore_on_save = []

        self.cutoff_len = 2048
        self.option_token_ids = [
            self._tokenize(letter, add_eos_token=False).input_ids[-1]
            for letter in "ABCDEFGHIJ"[:int(conf.get("num_cans", 10))]
        ]
        self.lm_loss_weight = float(conf.get("lm_loss_weight", 1.0))
        self.classification_loss_weight = float(conf.get("classification_loss_weight", 1.0))
        self.margin_loss_weight = float(conf.get("margin_loss_weight", 0.25))
        self.compatibility_loss_weight = float(conf.get("compatibility_loss_weight", 0.25))
        self.distillation_loss_weight = float(conf.get("distillation_loss_weight", 0.0))
        self.distillation_temperature = float(conf.get("distillation_temperature", 1.0))
        self.uncertainty_gate_power = float(conf.get("uncertainty_gate_power", 0.0))
        self.base_margin = float(conf.get("base_margin", 0.2))
        self.hardness_margin_scale = float(conf.get("hardness_margin_scale", 0.3))
        self.compatibility_temperature = float(conf.get("compatibility_temperature", 0.1))
        self.last_loss_components = {}

    def _get_caption(self, item_id):
        item = self.item_info[str(int(item_id))]
        if self.dataset_name.startswith("spotify"):
            track = str(item.get("track_name", "")).strip()
            artist = str(item.get("artist_name", "")).strip()
            album = str(item.get("album_name", "")).strip()
            if self.text_format == "track":
                value = track
            elif self.text_format == "artist_track":
                value = " - ".join(part for part in (artist, track) if part)
            elif self.text_format == "artist_track_album":
                value = " - ".join(part for part in (artist, track, album) if part)
            else:
                raise ValueError(f"Unsupported Spotify text_format: {self.text_format}")
            if value:
                return value
        for key in ("title_en", "title", "track_name"):
            value = item.get(key)
            if value not in (None, ""):
                return str(value)
        raise KeyError(
            f"No textual title field for item {item_id}; available fields: {sorted(item)}"
        )

    def _embed_tokens(self, token_ids):
        if hasattr(self.llama_model.base_model, 'model'):
            embed_tokens = self.llama_model.base_model.base_model.embed_tokens
        else:
            embed_tokens = self.llama_model.base_model.embed_tokens

        token_ids = token_ids.long().to(embed_tokens.weight.device)
        return embed_tokens(token_ids)

    def generate_prompt(self, input_, target_):
        if self.dataset_name[:7] == "spotify":
            t_name = "playlist continuation"
            b_name = "music playlist"
            i_name = "song"
        else:
            t_name = "bundle construction"
            b_name = "fashion outfit"
            i_name = "fashion item"

        if "Llama-2-7b-chat-hf" in self.llama_model_path:
            chat = [
                {"role": "system",
                 "content": f"""You are a helpful and honest assistant. The following are multiple choice questions about {t_name}. You should directly answer the question by choosing the letter of the correct option. Only provide the letter of your answer, without any explanation or mentioning the option content."""},
                {"role": "user",
                 "content": f"""Given the partial {i_name}s: {input_}, which candidate {i_name} should be included into this {b_name}?\nOptions: {target_}\nYYour answer should indicate your choice with a single letter (e.g., “A,” “B,” “C,” etc.)."""},
                {"role": "assistant", "content": "The answer is "}
            ]
            return self.tokenizer.apply_chat_template(chat, tokenize=False).replace("<s>", "").replace("</s>", "")

        elif "Llama-2-7b-hf" in self.llama_model_path:
            if self.conf.get("prompt_style") == "compact":
                return (
                    f"Given bundle: {input_}\n"
                    f"Which candidate should be included?\nOptions: {target_}\n"
                    "Answer with one option letter.\nChoice: "
                )
            if self.conf.get("prompt_style") == "minimal":
                return f"Bundle: {input_}\nCandidates: {target_}\nChoice: "
            return f"""You are a helpful and honest assistant. The following are multiple choice questions about {t_name}. You should directly answer the question by choosing the letter of the correct option. Only provide the letter of your answer, without any explanation or mentioning the option content. Question: Given the partial {b_name}: {input_}, which candidate {i_name} should be included into this {b_name}?\nOptions: {target_}\nYour answer should indicate your choice with a single letter (e.g., “A,” “B,” “C,” etc.).\nChoice: """
        else:
            return f"""You are a helpful and honest assistant. The following are multiple choice questions about {t_name}. You should directly answer the question by choosing the letter of the correct option. Only provide the letter of your answer, without any explanation or mentioning the option content. Question: Given the partial {b_name}: {input_}, which candidate {i_name} should be included into this {b_name}?\nOptions: {target_}\nYour answer should indicate your choice with a single letter (e.g., “A,” “B,” “C,” etc.).\nChoice: """
    def print_trainable_params(self):
        print('Trainable parameters:')
        for name, param in self.named_parameters():
            if param.requires_grad:
                print('\t' + name)

    def _gen_yes_or_no_ids(self, gt_label):
        label_ids = [3869 if float(gt_label) > 0.5 else 1939, 29889]
        return torch.Tensor(label_ids)

    def _gen_label_ids(self, gt_label, title):
        label_ids = self._tokenize(f"{chr(ord('A') + int(gt_label))}.", add_eos_token=False).input_ids

        return torch.Tensor(label_ids)

    def _tokenize(self, prompt, cutoff_len=None, add_eos_token=True):
        if cutoff_len is None:
            cutoff_len = self.cutoff_len
        result = self.tokenizer(
            prompt,
            truncation=True,
            max_length=cutoff_len,
            padding=False,
            return_tensors=None,
        )

        if (
                result["input_ids"][-1] != self.tokenizer.eos_token_id
                and len(result["input_ids"]) < self.cutoff_len
                and add_eos_token
        ):
            result["input_ids"].append(self.tokenizer.eos_token_id)
        return result

    def forward(self, gt_label, indices, candidates):
        fast_inference = bool(self.conf.get("fast_candidate_inference", False)) and not self.training
        inputs_embeds_list = []
        label_ids = []
        compatibility_logits_list = []
        hardness_list = []
        reranker_logits_list = []
        for i in range(len(indices)):
            attn = indices[i] != self.num_item
            input_indices = indices[i][:attn.sum()].tolist()
            input_candidates = candidates[i].tolist()
            input_ = ""
            target_ = ""
            for idx, j in enumerate(input_indices):
                str_dict = {
                    "mm": "content token: <Feature>" if not self.conf["soft_prompt"] else "<Feature>",  # soft_prompt
                    "text": self._get_caption(j)
                }
                str_ = []
                for m in ["text", "mm", "ui", "bi"]:
                    if m in self.mode:
                        str_.append(str_dict[m])
                input_ += f"{idx + 1}. " + ", ".join(str_) + "; "

            for idx, j in enumerate(input_candidates):
                str_dict = {
                    "mm": "content token: <Feature>" if not self.conf["soft_prompt"] else "<Feature>",  # soft_prompt
                    "text": self._get_caption(j)
                }
                str_ = []
                for m in ["text", "mm"]:
                    if m in self.mode:
                        str_.append(str_dict[m])
                target_ += f"{chr(ord('A') + idx)}. " + ", ".join(str_) + "; "

            prompt_emb = [self.bos_embeds.unsqueeze(0)]
            all_indices = torch.tensor(input_indices + input_candidates, dtype=torch.long, device=self.device)
            all_proj_features = []
            if "mm" in self.mode:
                fused_features = self.fusion(all_indices.unsqueeze(0), self.prompt_token)
                all_proj_features.append(
                    self.projector(fused_features).squeeze(0)
                )
                context_count = len(input_indices)
                context_feature = F.normalize(
                    fused_features[0, :context_count].mean(dim=0), dim=0
                )
                candidate_features = F.normalize(fused_features[0, context_count:], dim=-1)
                context_expanded = context_feature.unsqueeze(0).expand_as(candidate_features)
                reranker_input = torch.cat([
                    context_expanded,
                    candidate_features,
                    context_expanded * candidate_features,
                    torch.abs(context_expanded - candidate_features),
                ], dim=-1)
                reranker_logits_list.append(
                    self.candidate_reranker(reranker_input).squeeze(-1)
                )
                raw_compatibility_logits = candidate_features @ context_feature
                if fast_inference:
                    compatibility_logits_list.append(raw_compatibility_logits)
                else:
                    compatibility_logits = raw_compatibility_logits / self.compatibility_temperature
                    compatibility_logits_list.append(compatibility_logits)

                    true_position = int(gt_label[i].item())
                    negative_mask = torch.ones(
                        compatibility_logits.numel(), dtype=torch.bool, device=self.device
                    )
                    negative_mask[true_position] = False
                    hardest_similarity = (
                        compatibility_logits[negative_mask].max()
                        * self.compatibility_temperature
                    )
                    hardness_list.append(hardest_similarity.detach().clamp(0.0, 1.0))
            count_feature_per = len(all_proj_features)

            if count_feature_per != 0:
                count_feature_all = count_feature_per * all_proj_features[0].shape[0]
                for idx, j in enumerate(self.generate_prompt(input_, target_).split("<Feature>")):
                    input_ids = torch.tensor(self._tokenize(j, add_eos_token=False).input_ids).to(self.device).long()
                    prompt_emb.append(self._embed_tokens(input_ids).unsqueeze(0))
                    if idx < count_feature_all:
                        if self.conf["soft_prompt"] and not self.conf["del_sp"]:
                            prompt_emb.append(self.prompt_token.weight.view(1, self.num_pt, -1))
                        prompt_emb.append(
                            all_proj_features[idx % count_feature_per][idx // count_feature_per].view(1, 1, -1))
            else:
                input_ids = torch.tensor(
                    self._tokenize(self.generate_prompt(input_, target_), add_eos_token=False).input_ids).to(
                    self.device).long()
                prompt_emb.append(self._embed_tokens(input_ids).unsqueeze(0))

            if fast_inference:
                # A fixed suffix preserves the trained sequence layout without using the ground-truth label.
                label = self._gen_label_ids(0, "").to(self.device).long()
            else:
                label = self._gen_label_ids(gt_label[i],
                                            self._get_caption(input_candidates[gt_label[i]])).to(
                    self.device).long()
            prompt_emb.append(self._embed_tokens(label).unsqueeze(0))
            inputs_embeds_list.append(torch.cat(prompt_emb, dim=1))
            label_ids.append(label)

        emb_lens = [inputs_embeds.shape[1] for inputs_embeds in inputs_embeds_list]
        emb_max_len = max(emb_lens)
        wrapped_embs = self.pad_embeds.expand(len(inputs_embeds_list), emb_max_len, -1).clone()
        wrapped_atts = torch.zeros(len(inputs_embeds_list), emb_max_len, dtype=torch.long).to(self.device)
        for i, inputs_embeds in enumerate(inputs_embeds_list):
            if self.padding_side == "left":
                wrapped_embs[i, - emb_lens[i]:] = inputs_embeds
                wrapped_atts[i, - emb_lens[i]:] = 1
            else:
                wrapped_embs[i, :emb_lens[i]] = inputs_embeds
                wrapped_atts[i, :emb_lens[i]] = 1

        model_kwargs = dict(
            inputs_embeds=wrapped_embs,
            attention_mask=wrapped_atts,
            return_dict=True,
        )
        prune_candidate_logits = fast_inference and not self.conf.get(
            "disable_candidate_logit_pruning", False
        )
        if fast_inference:
            logits_to_keep = max(int(label_id.numel()) for label_id in label_ids) + 1
            if prune_candidate_logits:
                model_kwargs["logits_to_keep"] = logits_to_keep
            model_kwargs["use_cache"] = False
        else:
            label_pad_ids = torch.full([len(wrapped_embs), emb_max_len], -100, dtype=torch.long).to(self.device)
            for i, label_id in enumerate(label_ids):
                if self.padding_side == "left":
                    label_pad_ids[i, - label_id.shape[0]:] = label_id
                else:
                    label_pad_ids[i, emb_lens[i] - label_id.shape[0]:emb_lens[i]] = label_id
            model_kwargs["labels"] = label_pad_ids
        if self.training_stage == "reranker_only":
            with torch.no_grad():
                outputs = self.llama_model(**model_kwargs)
        else:
            outputs = self.llama_model(**model_kwargs)

        option_token_ids = torch.tensor(
            self.option_token_ids, dtype=torch.long, device=self.device
        )
        self.last_efficiency_metrics = {
            "input_token_counts": emb_lens,
            "useful_input_tokens": int(sum(emb_lens)),
            "padded_input_tokens": int(len(emb_lens) * emb_max_len),
            "padding_tokens": int(len(emb_lens) * emb_max_len - sum(emb_lens)),
            "logit_elements": int(outputs.logits.numel()),
            "candidate_logit_pruning": bool(prune_candidate_logits),
        }
        if prune_candidate_logits:
            prediction_positions = torch.tensor([
                logits_to_keep - int(label_id.numel()) - 1 for label_id in label_ids
            ], dtype=torch.long, device=self.device)
            batch_positions = torch.arange(len(label_ids), device=self.device)
            option_logits = outputs.logits[batch_positions, prediction_positions]
        else:
            prediction_positions = torch.tensor([
                emb_max_len - int(label_id.numel()) - 1 for label_id in label_ids
            ], dtype=torch.long, device=self.device)
            batch_positions = torch.arange(len(label_ids), device=self.device)
            option_logits = outputs.logits[batch_positions, prediction_positions]
        option_logits = option_logits.index_select(-1, option_token_ids)
        normalized_option_logits = (
            option_logits.float() - option_logits.float().mean(dim=-1, keepdim=True)
        ) / option_logits.float().std(dim=-1, keepdim=True).clamp_min(1e-4)
        if reranker_logits_list:
            reranker_logits = torch.stack(reranker_logits_list).float()
            reranker_logits = reranker_logits - reranker_logits.mean(dim=-1, keepdim=True)
            rerank_gate = torch.sigmoid(self.rerank_gate_logit)
            base_prob = F.softmax(normalized_option_logits.detach(), dim=-1)
            normalized_entropy = -(base_prob * base_prob.clamp_min(1e-8).log()).sum(dim=-1)
            normalized_entropy = normalized_entropy / math.log(base_prob.shape[-1])
            uncertainty_gate = normalized_entropy.clamp(0.0, 1.0).pow(self.uncertainty_gate_power)
            decision_logits = (
                normalized_option_logits
                + rerank_gate * uncertainty_gate.unsqueeze(-1) * reranker_logits
            )
        else:
            rerank_gate = option_logits.new_zeros(())
            uncertainty_gate = option_logits.new_zeros(option_logits.shape[0])
            decision_logits = normalized_option_logits
        if fast_inference:
            result = {"logits": decision_logits}
            if compatibility_logits_list:
                result["fusion_logits"] = torch.stack(compatibility_logits_list).float()
            return result
        targets = gt_label.view(-1).long().to(self.device)

        classification_loss = F.cross_entropy(decision_logits, targets)
        true_logits = decision_logits.gather(1, targets.unsqueeze(1)).squeeze(1)
        negative_logits = decision_logits.masked_fill(
            F.one_hot(targets, num_classes=decision_logits.shape[1]).bool(),
            torch.finfo(decision_logits.dtype).min,
        ).max(dim=1).values
        if hardness_list:
            hardness = torch.stack(hardness_list).to(true_logits.dtype)
        else:
            hardness = torch.zeros_like(true_logits)
        adaptive_margin = self.base_margin + self.hardness_margin_scale * hardness
        margin_loss = F.relu(adaptive_margin - true_logits + negative_logits).mean()

        if compatibility_logits_list:
            compatibility_logits = torch.stack(compatibility_logits_list)
            compatibility_loss = F.cross_entropy(compatibility_logits.float(), targets)
        else:
            compatibility_loss = outputs.loss.new_zeros(())

        temperature = max(self.distillation_temperature, 1e-4)
        distillation_loss = F.kl_div(
            F.log_softmax(decision_logits / temperature, dim=-1),
            F.softmax(normalized_option_logits.detach() / temperature, dim=-1),
            reduction="batchmean",
        ) * (temperature ** 2)

        total_loss = (
            self.lm_loss_weight * outputs.loss
            + self.classification_loss_weight * classification_loss
            + self.margin_loss_weight * margin_loss
            + self.compatibility_loss_weight * compatibility_loss
            + self.distillation_loss_weight * distillation_loss
        )
        self.last_loss_components = {
            "lm": float(outputs.loss.detach().float().item()),
            "classification": float(classification_loss.detach().float().item()),
            "margin": float(margin_loss.detach().float().item()),
            "compatibility": float(compatibility_loss.detach().float().item()),
            "distillation": float(distillation_loss.detach().float().item()),
            "rerank_gate": float(rerank_gate.detach().float().item()),
            "uncertainty_gate": float(uncertainty_gate.detach().float().mean().item()),
        }

        return {
            "loss": total_loss,
            "logits": decision_logits,
        }

    def score_fusion_candidates(self, indices, candidates):
        """Score candidates without invoking Llama; used for selective early exit."""
        score_rows = []
        for i in range(len(indices)):
            input_indices = indices[i][indices[i] != self.num_item].tolist()
            input_candidates = candidates[i].tolist()
            all_indices = torch.tensor(
                input_indices + input_candidates, dtype=torch.long, device=self.device
            )
            fused = self.fusion(all_indices.unsqueeze(0), self.prompt_token)[0]
            context = F.normalize(fused[:len(input_indices)].mean(dim=0), dim=0)
            candidate_features = F.normalize(fused[len(input_indices):], dim=-1)
            score_rows.append(candidate_features @ context)
        return torch.stack(score_rows).float()

    def generate(self, inputs_embeds_list, config):
        emb_lens = [inputs_embeds.shape[1] for inputs_embeds in inputs_embeds_list]
        emb_max_len = max(emb_lens)
        wrapped_embs = self.pad_embeds.expand(len(inputs_embeds_list), emb_max_len, -1).clone()
        wrapped_atts = torch.zeros(len(inputs_embeds_list), emb_max_len, dtype=torch.long).to(self.device)
        for i, inputs_embeds in enumerate(inputs_embeds_list):
            if self.padding_side == "left":
                wrapped_embs[i, (emb_max_len - emb_lens[i]):] = inputs_embeds
                wrapped_atts[i, (emb_max_len - emb_lens[i]):] = 1
            else:
                wrapped_embs[i, :emb_lens[i]] = inputs_embeds
                wrapped_atts[i, :emb_lens[i]] = 1

        self.token_lens = emb_lens
        self.last_generation_input_metrics = {
            "input_token_counts": emb_lens,
            "useful_input_tokens": int(sum(emb_lens)),
            "padded_input_tokens": int(len(emb_lens) * emb_max_len),
            "padding_tokens": int(len(emb_lens) * emb_max_len - sum(emb_lens)),
        }

        return self.llama_model.generate(
            inputs_embeds=wrapped_embs,
            attention_mask=wrapped_atts,
            generation_config=config,
            return_dict_in_generate=True,
            output_scores=True,
        )

    def evaluate(self, indices, candidates, config):

        inputs_embeds_list = []
        for i in range(len(indices)):
            attn = indices[i] != self.num_item
            input_indices = indices[i][:attn.sum()].tolist()
            input_candidates = candidates[i].tolist()
            input_ = ""
            target_ = ""
            for idx, j in enumerate(input_indices):
                str_dict = {
                    "mm": "content token: <Feature>" if not self.conf["soft_prompt"] else "<Feature>",  # soft_prompt
                    "text": self._get_caption(j)
                }
                str_ = []
                for m in ["text", "mm"]:
                    if m in self.mode:
                        str_.append(str_dict[m])
                input_ += f"{idx + 1}. " + ", ".join(str_) + "; "

            for idx, j in enumerate(input_candidates):
                str_dict = {
                    "mm": "content token: <Feature>" if not self.conf["soft_prompt"] else "<Feature>",  # soft_prompt
                    "text": self._get_caption(j)
                }
                str_ = []
                for m in ["text", "mm"]:
                    if m in self.mode:
                        str_.append(str_dict[m])
                target_ += f"{chr(ord('A') + idx)}. " + ", ".join(str_) + "; "

            prompt_emb = [self.bos_embeds.unsqueeze(0)]
            all_indices = torch.tensor(input_indices + input_candidates)
            all_proj_features = []
            if "mm" in self.mode:
                fused_features = self.fusion(all_indices.unsqueeze(0), self.prompt_token)
                all_proj_features.append(
                    self.projector(fused_features).squeeze(0)
                )
            count_feature_per = len(all_proj_features)

            if count_feature_per != 0:
                count_feature_all = count_feature_per * all_proj_features[0].shape[0]
                for idx, j in enumerate(self.generate_prompt(input_, target_).split("<Feature>")):
                    input_ids = torch.tensor(self._tokenize(j, add_eos_token=False).input_ids).to(self.device).long()
                    prompt_emb.append(self._embed_tokens(input_ids).unsqueeze(0))
                    if idx < count_feature_all:
                        if self.conf["soft_prompt"] and not self.conf["del_sp"]:
                            prompt_emb.append(self.prompt_token.weight.view(1, self.num_pt, -1))
                        prompt_emb.append(
                            all_proj_features[idx % count_feature_per][idx // count_feature_per].view(1, 1, -1))
            else:
                input_ids = torch.tensor(
                    self._tokenize(self.generate_prompt(input_, target_), add_eos_token=False).input_ids).to(
                    self.device).long()
                prompt_emb.append(self._embed_tokens(input_ids).unsqueeze(0))

            inputs_embeds_list.append(torch.cat(prompt_emb, dim=1))

        return self.generate(inputs_embeds_list, config)


def init(m):
    if isinstance(m, nn.Linear):
        nn.init.xavier_normal_(m.weight)
        if m.bias is not None:
            nn.init.constant_(m.bias, 0)
    elif isinstance(m, nn.Parameter):
        nn.init.xavier_uniform_(m)
    elif isinstance(m, nn.Embedding):
        nn.init.xavier_uniform_(m.weight)
