import argparse
import json
import os
import random
import shutil
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
import yaml

from model_spotify_eval import BundleMLLM
from utils_spotify_repro import Datasets, setup_seeds


PROJECT = Path.cwd()
BASE_MODEL = PROJECT.parent / "llama-2-7b-hf"
BASE_CHECKPOINT = PROJECT / "experiments/innovation_retest_20260903/spotify_sparse/s2_artist_track_album/best-checkpoint"
INSTRUCTION = (
    "For each independent playlist continuation question, choose the one correct candidate from A through J. "
    "Questions do not affect one another. Use the fixed answer slots at the end."
)


def atomic_json(path, payload):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2, sort_keys=True); handle.write("\n")
    os.replace(temporary, path)


def build_model(gpu, checkpoint, trainable):
    os.environ["CUDA_VISIBLE_DEVICES"] = str(gpu)
    device = torch.device("cuda:0")
    with open("config.yaml", encoding="utf-8") as handle:
        conf = yaml.safe_load(handle)["spotify_sparse"]
    conf.update({
        "dataset": "spotify_sparse", "device": device, "base_model": str(BASE_MODEL),
        "pretrain_model_path": str(checkpoint), "from_pretrain": True, "mode": "text+mm",
        "few_shot": 1024, "toy_eval": 2048, "num_token": 5, "num_cans": 10,
        "soft_prompt": True, "del_sp": False, "train_lora": trainable,
        "components": "", "sp_guided": False, "sp_sg": False,
        "training_stage": "joint", "num_workers": 0,
        "batch_size_train": 16, "batch_size_test": 16,
        "fast_candidate_inference": True, "disable_candidate_logit_pruning": False,
        "uncertainty_gate_power": 0.0, "compatibility_temperature": 0.1,
        "base_margin": 0.2, "hardness_margin_scale": 0.3,
        "text_format": "artist_track_album", "active_modalities": ["content", "bi", "cf"],
    })
    setup_seeds(42)
    data = Datasets(conf)
    conf.update(num_users=data.num_users, num_bundles=data.num_bundles, num_items=data.num_items)
    model = BundleMLLM(conf, data.graphs, data.features, data.item_info, is_training=trainable).to(device)
    for parameter in model.parameters():
        parameter.requires_grad = False
    if trainable:
        for name, parameter in model.llama_model.named_parameters():
            if "lora_" in name:
                parameter.requires_grad = True
    return model, data, device


class PromptBuilder:
    def __init__(self, model):
        self.model = model
        self.token_cache = {}
        self.option_ids = torch.tensor(model.option_token_ids, device=model.device)
        if model.dataset_name.startswith("spotify"):
            self.instruction = INSTRUCTION
            self.context_label = "Partial playlist"
        else:
            self.instruction = (
                "For each independent product bundle completion question, choose the one correct "
                "candidate from A through J. Questions do not affect one another. Use the fixed "
                "answer slots at the end."
            )
            self.context_label = "Partial product bundle"

    def ids(self, text):
        if text not in self.token_cache:
            self.token_cache[text] = self.model.tokenizer(
                text, add_special_tokens=False, return_tensors=None
            ).input_ids
        return torch.tensor(self.token_cache[text], device=self.model.device, dtype=torch.long)

    def text(self, value):
        return self.model._embed_tokens(self.ids(value)).unsqueeze(0)

    def pack(self, group):
        pieces = [self.model.bos_embeds.unsqueeze(0), self.text(self.instruction + "\n")]
        with torch.no_grad():
            for slot, (_, indices, _, candidates) in enumerate(group, 1):
                context = [int(i) for i in indices.tolist() if int(i) != self.model.num_item]
                candidate_ids = [int(i) for i in candidates.tolist()]
                all_items = context + candidate_ids
                fused = self.model.fusion(torch.tensor([all_items], device=self.model.device), self.model.prompt_token)
                projected = self.model.projector(fused)[0].detach()
                pieces.append(self.text(f"\nQuestion {slot}\n{self.context_label}:\n"))
                for number, item in enumerate(context, 1):
                    pieces.extend([
                        self.text(f"{number}. {self.model._get_caption(item)} "),
                        self.model.prompt_token.weight.detach().view(1, 1, -1),
                        projected[number - 1].view(1, 1, -1), self.text(";\n"),
                    ])
                pieces.append(self.text("Candidates:\n"))
                offset = len(context)
                for number, item in enumerate(candidate_ids):
                    pieces.extend([
                        self.text(f"{chr(65 + number)}. {self.model._get_caption(item)} "),
                        self.model.prompt_token.weight.detach().view(1, 1, -1),
                        projected[offset + number].view(1, 1, -1), self.text(";\n"),
                    ])
        pieces.append(self.text("\nIndependent answer slots:\n"))
        positions = []
        length = sum(piece.shape[1] for piece in pieces)
        for slot in range(1, len(group) + 1):
            marker = self.text(f"Question {slot}: ")
            pieces.append(marker); length += marker.shape[1]; positions.append(length - 1)
            separator = self.text("|\n")
            pieces.append(separator); length += separator.shape[1]
        return torch.cat(pieces, dim=1), positions

    def score(self, groups, gradient):
        packed = [self.pack(group) for group in groups]
        maximum = max(value[0].shape[1] for value in packed)
        if maximum > self.model.llama_model.config.max_position_embeddings:
            raise RuntimeError(f"prompt length {maximum} exceeds context window")
        embedding_size = packed[0][0].shape[-1]
        embeddings = self.model.pad_embeds.view(1, 1, embedding_size).expand(len(groups), maximum, embedding_size).clone()
        attention = torch.zeros(len(groups), maximum, dtype=torch.long, device=self.model.device)
        aligned = []
        useful = 0
        for row, (value, positions) in enumerate(packed):
            size = value.shape[1]; useful += size
            embeddings[row, -size:] = value[0]; attention[row, -size:] = 1
            aligned.append([position + maximum - size for position in positions])
        if any(row != aligned[0] for row in aligned[1:]):
            raise RuntimeError("answer positions did not align after left padding")
        position_tensor = torch.tensor(aligned[0], dtype=torch.long, device=self.model.device)
        context = torch.enable_grad() if gradient else torch.no_grad()
        with context, torch.autocast("cuda", dtype=torch.bfloat16):
            outputs = self.model.llama_model(
                inputs_embeds=embeddings, attention_mask=attention,
                logits_to_keep=position_tensor, use_cache=False, return_dict=True,
            )
            logits = outputs.logits.index_select(-1, self.option_ids).float()
        return logits, useful, len(groups) * maximum


def materialize(rows):
    return [(row[0], row[1], row[2].reshape(-1)[0], row[3]) for row in rows]


def evaluate_structured(model, builder, rows, group_size):
    groups = [rows[index:index + group_size] for index in range(0, len(rows), group_size)]
    groups_per_call = max(1, 8 // group_size)
    hits = samples = useful = padded = model_calls = 0
    position = {str(i): {"hits": 0, "samples": 0} for i in range(1, group_size + 1)}
    torch.cuda.empty_cache(); torch.cuda.reset_peak_memory_stats(model.device)
    started = time.perf_counter(); model.eval()
    for index in range(0, len(groups), groups_per_call):
        current = groups[index:index + groups_per_call]
        logits, batch_useful, batch_padded = builder.score(current, gradient=False)
        useful += batch_useful; padded += batch_padded; model_calls += 1
        for group_index, group in enumerate(current):
            predictions = logits[group_index, :len(group)].argmax(-1).cpu().tolist()
            for slot, (prediction, row) in enumerate(zip(predictions, group), 1):
                target = int(row[2]); correct = int(prediction == target)
                hits += correct; samples += 1
                position[str(slot)]["hits"] += correct; position[str(slot)]["samples"] += 1
    torch.cuda.synchronize(); elapsed = time.perf_counter() - started
    for row in position.values():
        row["hitrate"] = row["hits"] / row["samples"] if row["samples"] else None
    return {
        "samples": samples, "hits": hits, "hitrate": hits / samples,
        "batch_prompt_size": group_size, "logical_prompts": len(groups), "model_calls": model_calls,
        "input_tokens": useful, "input_tokens_per_sample": useful / samples,
        "padded_tokens": padded, "seconds": elapsed, "seconds_per_sample": elapsed / samples,
        "peak_allocated_mib": torch.cuda.max_memory_allocated(model.device) / 2**20,
        "position_metrics": position,
    }


def evaluate_original(model, data_rows):
    hits = samples = useful = padded = model_calls = 0
    torch.cuda.empty_cache(); torch.cuda.reset_peak_memory_stats(model.device)
    started = time.perf_counter(); model.eval()
    for index in range(0, len(data_rows), 8):
        group = data_rows[index:index + 8]
        indices = torch.stack([row[1] for row in group]).to(model.device)
        targets = torch.tensor([int(row[2]) for row in group], device=model.device)
        candidates = torch.stack([row[3] for row in group]).to(model.device)
        with torch.no_grad(), torch.autocast("cuda", dtype=torch.bfloat16):
            output = model(targets, indices, candidates)
        prediction = output["logits"].argmax(-1)
        hits += int((prediction == targets).sum()); samples += len(group); model_calls += 1
        telemetry = model.last_efficiency_metrics
        useful += telemetry["useful_input_tokens"]; padded += telemetry["padded_input_tokens"]
    torch.cuda.synchronize(); elapsed = time.perf_counter() - started
    return {
        "samples": samples, "hits": hits, "hitrate": hits / samples,
        "logical_prompts": samples, "model_calls": model_calls,
        "input_tokens": useful, "input_tokens_per_sample": useful / samples,
        "padded_tokens": padded, "seconds": elapsed, "seconds_per_sample": elapsed / samples,
        "peak_allocated_mib": torch.cuda.max_memory_allocated(model.device) / 2**20,
    }


def save_adapter(model, directory, metadata):
    directory = Path(directory)
    if directory.exists(): shutil.rmtree(directory)
    directory.mkdir(parents=True)
    model.llama_model.save_pretrained(directory)
    for name in ("fusion.bin", "projector_model_fuse.bin", "prompt_token.bin"):
        source = BASE_CHECKPOINT / name
        if source.exists(): shutil.copy2(source, directory / name)
    atomic_json(directory / "s3_summary.json", metadata)


def train_group(args):
    output = Path(args.output)
    model, data, device = build_model(args.gpu, BASE_CHECKPOINT, True)
    builder = PromptBuilder(model)
    trainable = [parameter for parameter in model.parameters() if parameter.requires_grad]
    if not trainable: raise RuntimeError("no trainable LoRA parameters")
    optimizer = torch.optim.AdamW(trainable, lr=5e-5)
    validation = materialize([data.val_data[index] for index in range(2048)])
    best_hits = -1; history = []
    consistency_weight = 0.2 if args.group == "E" else 0.0
    for epoch in range(1, 11):
        setup_seeds(4200 + epoch)
        examples = materialize([data.train_data[index] for index in range(1024)])
        random.Random(4200 + epoch).shuffle(examples)
        if args.group == "C":
            group_sets = [(1, examples)]
        else:
            # Exactly 1024 questions per epoch, split across B=1,2,4.
            group_sets = [(1, examples[:344]), (2, examples[344:684]), (4, examples[684:1024])]
        steps = []
        for group_size, section in group_sets:
            groups = [section[index:index + group_size] for index in range(0, len(section), group_size)]
            groups_per_step = 8 // group_size
            steps.extend([groups[index:index + groups_per_step] for index in range(0, len(groups), groups_per_step)])
        random.Random(8400 + epoch).shuffle(steps)
        model.train(); losses = []
        for current in steps:
            teacher = None
            if consistency_weight:
                singles = [[row] for group in current for row in group]
                model.eval()
                teacher, _, _ = builder.score(singles, gradient=False)
                teacher = teacher[:, 0].detach()
                model.train()
            logits, _, _ = builder.score(current, gradient=True)
            labels = torch.tensor([[int(row[2]) for row in group] for group in current], device=device)
            loss = F.cross_entropy(logits.reshape(-1, 10), labels.reshape(-1))
            if teacher is not None:
                batch_logits = logits.reshape(-1, 10)
                correct_teacher = teacher.argmax(-1).eq(labels.reshape(-1)).float()
                divergence = F.kl_div(
                    F.log_softmax(batch_logits, -1), F.softmax(teacher, -1), reduction="none"
                ).sum(-1)
                if correct_teacher.sum() > 0:
                    loss = loss + consistency_weight * (divergence * correct_teacher).sum() / correct_teacher.sum()
            optimizer.zero_grad(set_to_none=True); loss.backward()
            torch.nn.utils.clip_grad_norm_(trainable, 1.0); optimizer.step(); losses.append(float(loss.detach()))
            if len(losses) % 32 == 0:
                print(json.dumps({"epoch": epoch, "step": len(losses), "loss": np.mean(losses[-32:])}), flush=True)
        selection_size = 1 if args.group == "C" else 4
        metrics = evaluate_structured(model, builder, validation, selection_size)
        row = {"epoch": epoch, "train_loss": float(np.mean(losses)), "validation": metrics}
        history.append(row); atomic_json(output / "history.json", history)
        if metrics["hits"] > best_hits:
            best_hits = metrics["hits"]
            save_adapter(model, output / "best-checkpoint", {
                "group": args.group, "epoch": epoch, "validation_hits": best_hits,
                "training_batch_prompt_sizes": [1] if args.group == "C" else [1, 2, 4],
                "selection_batch_prompt_size": selection_size, "consistency_weight": consistency_weight,
                "training_questions_per_epoch": 1024, "epochs": 10, "learning_rate": 5e-5,
            })
    atomic_json(output / "training_complete.json", {"best_hits": best_hits, "history": history})


def evaluate_group(args):
    output = Path(args.output)
    checkpoint = BASE_CHECKPOINT if args.group in ("A", "B") else output / "best-checkpoint"
    model, data, _ = build_model(args.gpu, checkpoint, False)
    builder = PromptBuilder(model)
    validation = materialize([data.val_data[index] for index in range(2048)])
    test = materialize([data.test_data[index] for index in range(2048)])
    if args.group == "A":
        payload = {"validation": evaluate_original(model, validation), "test": evaluate_original(model, test)}
    else:
        sizes = [2, 4, 8] if args.group == "B" else [1, 2, 4, 8]
        payload = {
            "validation": {str(size): evaluate_structured(model, builder, validation, size) for size in sizes},
            "test": {str(size): evaluate_structured(model, builder, test, size) for size in sizes},
        }
    payload.update({
        "group": args.group, "checkpoint": str(checkpoint),
        "protocol": "released split; 1024 training questions for adapted groups; first 2048 validation and test candidate rows; candidates unchanged",
    })
    atomic_json(output / "metrics.json", payload)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--group", choices=list("ABCDE"), required=True)
    parser.add_argument("--gpu", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--phase", choices=["train", "evaluate"], required=True)
    args = parser.parse_args()
    if args.phase == "train": train_group(args)
    else: evaluate_group(args)


if __name__ == "__main__":
    main()
