"""Historical native Trainer with rebuilt BI and original validation selection."""
import argparse
import json
import math
from pathlib import Path
import torch
import transformers
from transformers import Trainer,TrainerCallback,EarlyStoppingCallback
from core import atomic
from filtered_data import configuration,load_data
from model import BundleMLLM
from utils import DataCollator,setup_seeds,preprocess_logits_for_metrics,compute_metrics

class RecordingDataset(torch.utils.data.Dataset):
    def __init__(self,sampler,dest):self.sampler=sampler;self.dest=dest;self.rows={}
    def __len__(self):return len(self.sampler)
    def __getitem__(self,index):
        row=self.sampler[index];self.rows[index]=row
        return row

class Progress(TrainerCallback):
    def __init__(self,out,dest,sampler,validation_n):self.out=out;self.dest=dest;self.sampler=sampler;self.validation_n=validation_n;self.history=[]
    def on_epoch_begin(self,args,state,control,**kwargs):self.sampler.rows={}
    def on_epoch_end(self,args,state,control,**kwargs):
        torch.save([self.sampler.rows[i] for i in sorted(self.sampler.rows)],self.dest/f'train_epoch{round(state.epoch):03d}.pt')
    def on_log(self,args,state,control,logs=None,**kwargs):
        rec={'phase':'single_training','stage':self.dest.name,'step':state.global_step,'epoch':state.epoch,**(logs or {})}
        atomic(self.out/'progress.json',rec);print(json.dumps(rec),flush=True)
    def on_evaluate(self,args,state,control,metrics=None,**kwargs):
        rec=dict(epoch=state.epoch,step=state.global_step,checkpoint=str(self.dest/f'checkpoint-{state.global_step}'),
            validation_hits=round(metrics['eval_hitrate']*self.validation_n),metrics=metrics,selection='validation')
        self.history.append(rec);atomic(self.dest/'history.json',self.history)

class HistoricalTrainer(Trainer):
    def _load_best_model(self):
        # Next stage constructs a new model from the saved selected PEFT files.
        pass
    def _save(self,output_dir=None,state_dict=None):
        p=Path(output_dir);p.mkdir(parents=True,exist_ok=True)
        self.model.llama_model.save_pretrained(p,safe_serialization=True)
        for attr,name in [('fusion','fusion.bin'),('projector','projector_model_fuse.bin'),('prompt_token','prompt_token.bin')]:
            torch.save(getattr(self.model,attr).state_dict(),p/name)
        torch.save(self.args,p/'training_args.bin')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True);ap.add_argument('--stage',choices=['single_text','single_multimodal'],required=True);a=ap.parse_args()
    out=Path(a.out);dest=out/a.stage;dest.mkdir();project=Path.cwd();setup_seeds(42);torch.set_num_threads(2)
    parent=None if a.stage=='single_text' else json.loads((out/'single_text/selection.json').read_text())['checkpoint']
    conf=configuration(project,out,'text' if parent is None else 'text+mm_20',parent)
    data=load_data(conf)
    allowed=set(json.loads((out/'data_boundary.json').read_text())['base_training_bundles'])
    assert set(map(int,data.train_data.bundles_map[:1024]))==allowed
    model=BundleMLLM(conf,data.graphs,data.features,data.item_info,is_training=True).to(conf['device'])
    model.llama_model.config.use_cache=False
    train=RecordingDataset(data.train_data,dest)
    validation=torch.load(out/'manifests/selection.pt',map_location='cpu',weights_only=False)
    atomic(dest/'protocol.json',dict(stage=a.stage,seed=42,source_checkpoint=parent,selection='validation',
        validation_rows=len(validation),lr=3e-4,warmup=20,max_epochs=200,patience=10,physical_batch=16,optimizer='adamw_torch',
        native_dynamic_sampling=True,unique_training_bundles=1024,bi_feature=str(out/'data'/conf['dataset']/(conf['dataset']+'_LightGCN_bi_feature.pt')),
        implementation='historical Sep13 compatibility native model and Trainer recipe',
        config={k:str(v) if k=='device' else v for k,v in conf.items()}))
    args=transformers.TrainingArguments(output_dir=str(dest),warmup_steps=20,num_train_epochs=200,
        learning_rate=3e-4,per_device_train_batch_size=16,per_device_eval_batch_size=16,fp16=True,
        logging_steps=8,optim='adamw_torch',eval_strategy='epoch',save_strategy='epoch',
        save_total_limit=None,load_best_model_at_end=True,metric_for_best_model='eval_hitrate',
        report_to='none',seed=42,data_seed=42,dataloader_num_workers=0,disable_tqdm=True,
        remove_unused_columns=False)
    cb=Progress(out,dest,train,len(validation))
    trainer=HistoricalTrainer(model=model,train_dataset=train,eval_dataset=validation,args=args,
        compute_metrics=compute_metrics,data_collator=DataCollator(),preprocess_logits_for_metrics=preprocess_logits_for_metrics,
        callbacks=[EarlyStoppingCallback(early_stopping_patience=10),cb])
    trainer.train()
    best=next(r for r in cb.history if Path(r['checkpoint'])==Path(trainer.state.best_model_checkpoint))
    atomic(dest/'selection.json',dict(best,source_checkpoint=parent,seed=42))
    atomic(dest/'complete.json',dict(status='complete',selected=best,epochs=trainer.state.epoch))

if __name__=='__main__':main()
