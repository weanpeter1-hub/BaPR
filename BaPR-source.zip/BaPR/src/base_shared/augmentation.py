"""Resample questions from the original training bundles only."""
import numpy as np
import torch
from core import second_view


def sample_epoch(dataset, source_rows, seed):
    mapping={int(b):i for i,b in enumerate(dataset.bundles_map)}
    numpy_state=np.random.get_state()
    torch_state=torch.get_rng_state()
    try:
        np.random.seed(seed)
        generator=torch.Generator().manual_seed(seed)
        torch.set_rng_state(generator.get_state())
        return [dataset[mapping[int(r[0])]] for r in source_rows]
    finally:
        np.random.set_state(numpy_state)
        torch.set_rng_state(torch_state)


def training_views(rows, mode, seed):
    if mode=='single': return [rows]
    if mode=='repeat': return [rows,list(rows)]
    if mode=='dual': return [rows,second_view(rows,seed,'dual')]
    raise ValueError(mode)


def choose_deployment(candidate, candidate_model, previous, previous_model):
    promote=candidate['validation']['hits']>previous['validation']['hits']
    return (candidate,candidate_model,True) if promote else (previous,previous_model,False)


def save_epoch_questions(dataset, source_rows, seed, path):
    rows=sample_epoch(dataset,source_rows,seed)
    torch.save(rows,path)
    return rows
