"""Matched repeat/dual supervision during joint batch-prompt adaptation."""
from core import second_view

def supervised_views(batch,dual,seed):
    return [batch,second_view(batch,seed,'dual') if dual else list(batch)]

def supervision_batches(batch,spec,seed):
    """Return prompt groups, aligned target rows, and mean-loss weights."""
    if spec.get('supervision')=='b4_b1_anchor':
        return [([batch[:4]],batch[:4],.25),([batch[4:]],batch[4:],.25),
                ([[row] for row in batch],batch,.5)]
    views=supervised_views(batch,spec['dual'],seed) if spec['views']==2 else [batch]
    return [([view[i:i+4]],view[i:i+4],len(view[i:i+4])/len(batch)/len(views))
            for view in views for i in range(0,len(view),4)]

def retain_followup(parent,candidate):
    return candidate['validation']['hits']>parent['validation']['hits']

def configure_joint(model):
    configure_adaptation(model,True)

def configure_adaptation(model,joint):
    model.zero_grad(set_to_none=True)
    model.requires_grad_(False)
    for name,p in model.llama_model.named_parameters():
        if 'lora_' in name:p.requires_grad_(True)
    model.fusion.requires_grad_(joint);model.projector.requires_grad_(joint)

def parent_for(stage,selected,initialization):
    parents={'native_multimodal':'native_text','late_batch':'native_multimodal','late_dual':'late_batch','early_joint':'native_multimodal'}
    return initialization if stage=='native_text' else selected[parents[stage]]['checkpoint']

def select_route(records):
    return max(['late_dual','early_joint'],key=lambda name:(records[name]['validation']['hits'],name=='late_dual'))
