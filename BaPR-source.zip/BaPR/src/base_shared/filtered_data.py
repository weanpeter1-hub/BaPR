"""Dataset-aware loader for filtered original-training bundle relations."""
import json
import shutil
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import scipy.sparse as sp
import torch
from core import atomic, file_hash
from utils import BundleTrainDataset, list2pairs

def read_bundles(path):
    rows={}
    for line in Path(path).read_text().splitlines():
        xs=[int(x.strip()) for x in line.split(',')]
        rows[xs[0]]=set(xs[1:])
    return rows

def filter_bundles(bundles, reserved, base_ids):
    if reserved & base_ids:raise ValueError('Reserved and base bundles overlap')
    if not (reserved|base_ids)<=bundles.keys():raise ValueError('Bundle outside original training split')
    return {bid:items for bid,items in bundles.items() if bid not in reserved}

def normalized_adjacency(pairs, n_left, n_items):
    a=pairs[:,0];b=pairs[:,1]+n_left
    row=torch.cat([a,b]);col=torch.cat([b,a]);n=n_left+n_items
    deg=torch.bincount(row,minlength=n).float().clamp_min(1)
    values=(deg[row]*deg[col]).rsqrt()
    return torch.sparse_coo_tensor(torch.stack([row,col]),values,(n,n)).coalesce()

def load_data(conf):
    dataset=conf['dataset'];path=Path(conf['data_path'])/dataset
    counts=json.loads((path/'count.json').read_text());nu,nb,ni=[counts[k] for k in ['#U','#B','#I']]
    pairs=list2pairs(path/'bi_train.txt');uip=list2pairs(path/'ui_full.txt')
    bi=sp.csr_matrix((np.ones(len(pairs)),(pairs[:,0],pairs[:,1])),shape=(nb,ni))
    ui=sp.csr_matrix((np.ones(len(uip)),(uip[:,0],uip[:,1])),shape=(nu,ni))
    features=tuple(torch.load(path/name,map_location=conf['device'],weights_only=False).detach()
        for name in ['content_feature.pt','description_feature.pt','item_cf_feature.pt',f'{dataset}_LightGCN_bi_feature.pt'])
    sampler=BundleTrainDataset(conf,pairs,bi,features,nb,None,None,1)
    conf.update(num_users=nu,num_bundles=nb,num_items=ni)
    return SimpleNamespace(num_users=nu,num_bundles=nb,num_items=ni,graphs=[ui,bi,bi],
        features=features,item_info=json.loads((path/'item_info.json').read_text()),train_data=sampler)

def configuration(project,out,mode='text',parent=None):
    import yaml
    dataset=json.loads((Path(out)/'data_boundary.json').read_text())['dataset']
    conf=yaml.safe_load((Path(project)/'config.yaml').read_text())[dataset]
    conf.update(dataset=dataset,data_path=str(Path(out)/'data'),device=torch.device('cuda:0'),
        base_model=str(Path(project).parent/'llama-2-7b-hf'),pretrain_model_path=str(parent) if parent else '',
        from_pretrain=parent is not None,mode=mode,few_shot=1024,toy_eval=2048,num_token=5,num_cans=10,
        soft_prompt=True,del_sp=(mode!='text'),train_lora=True,components='',sp_guided=False,sp_sg=False,
        batch_size_train=16,batch_size_test=16,num_workers=0,active_modalities=['content','bi','cf'])
    return conf
