"""Fixed bundle-level reallocation; no model scores or labels select partitions."""
import math
import random
from collections import defaultdict

def stratified_bundle_split(bundle_sizes,seed):
    strata=defaultdict(list)
    for bid,size in sorted(bundle_sizes.items()):strata[size].append(bid)
    target=len(bundle_sizes)//2
    quotas={size:len(ids)//2 for size,ids in strata.items()}
    for size in sorted(strata,key=lambda k:(-(len(strata[k])%2),k))[:target-sum(quotas.values())]:quotas[size]+=1
    rng=random.Random(seed);correction=set()
    for size,ids in sorted(strata.items()):
        rng.shuffle(ids);correction.update(ids[:quotas[size]])
    return correction,set(bundle_sizes)-correction,quotas

def partition_rows(rows,correction,selection):
    return ([r for r in rows if int(r[0]) in correction], [r for r in rows if int(r[0]) in selection])

def evaluation_windows(n,width=8):
    if n<width:raise ValueError('Expected at least one full physical batch')
    for offset in range(0,n,width):
        stop=min(offset+width,n);start=min(offset,n-width)
        yield start,stop,offset-start

def head_schedule(n):
    per_epoch=math.ceil(n/64)
    return per_epoch,[epoch*per_epoch for epoch in (0,10,20,40,80)]
