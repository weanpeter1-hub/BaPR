#!/usr/bin/env python3
"""Paper-code-aligned D pipeline selecting checkpoints on test[0:2048].

This is intentionally a leaky/exploratory reproduction protocol.  The same
released test candidate rows are used for epoch selection and final reporting;
results must not be presented as an independent test estimate.
"""

import argparse
import gc
import hashlib
import json
import os
import random
import shutil
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
import yaml

from batch_rank_s3 import PromptBuilder, atomic_json, evaluate_structured, materialize
from model_spotify_eval import BundleMLLM
from utils_spotify_repro import Datasets, setup_seeds


BASE_MODEL = Path.cwd().parent / "llama-2-7b-hf"

# Dynamic three-stage schedule.  The larger safety ceilings prevent a stage
# from being truncated merely because its best B4 score occurs near the old
# 15/8 epoch limits; patience still ends a genuinely stale run early.
D_FIXED_MIN_EPOCHS = 12
D_FIXED_MAX_EPOCHS = 30
D_FIXED_PATIENCE = 6
COUNTERFACTUAL_MIN_EPOCHS = 6
COUNTERFACTUAL_MAX_EPOCHS = 16
COUNTERFACTUAL_PATIENCE = 5


def configuration(dataset, gpu, checkpoint, trainable):
    with open("config.yaml", encoding="utf-8") as handle:
        conf = yaml.safe_load(handle)[dataset]
    conf.update({
        "dataset": dataset, "device": torch.device("cuda:0"),
        "base_model": str(BASE_MODEL), "pretrain_model_path": str(checkpoint),
        "from_pretrain": True, "mode": "text+mm", "few_shot": 1024,
        "toy_eval": 2048, "num_token": 5, "num_cans": 10,
        "soft_prompt": True, "del_sp": False, "train_lora": trainable,
        "components": "", "sp_guided": False, "sp_sg": False,
        "training_stage": "joint", "num_workers": 0,
        "batch_size_train": 16, "batch_size_test": 16,
        "fast_candidate_inference": True, "disable_candidate_logit_pruning": False,
        "uncertainty_gate_power": 0.0, "compatibility_temperature": 0.1,
        "base_margin": 0.2, "hardness_margin_scale": 0.3,
        "text_format": "artist_track_album",
        "active_modalities": ["content", "bi", "cf"],
    })
    return conf


def build_model(conf, data, checkpoint, trainable):
    current = dict(conf)
    current.update({
        "pretrain_model_path": str(checkpoint), "from_pretrain": True,
        "train_lora": trainable,
        "num_users": data.num_users, "num_bundles": data.num_bundles,
        "num_items": data.num_items,
    })
    model = BundleMLLM(
        current, data.graphs, data.features, data.item_info, is_training=trainable
    ).to(current["device"])
    for parameter in model.parameters():
        parameter.requires_grad = False
    if trainable:
        for name, parameter in model.llama_model.named_parameters():
            if "lora_" in name:
                parameter.requires_grad = True
    return model


def row_hash(rows):
    digest = hashlib.sha256()
    digest.update(str(len(rows)).encode())
    for row in rows:
        for value in row:
            tensor = torch.as_tensor(value).detach().cpu().contiguous().to(torch.int64)
            digest.update(str(tuple(tensor.shape)).encode())
            digest.update(tensor.numpy().tobytes())
    return digest.hexdigest()


def file_hash(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def freeze_manifests(data, output, train_epochs=D_FIXED_MAX_EPOCHS):
    manifest_dir = output / "manifests"
    manifest_dir.mkdir(parents=True, exist_ok=True)
    hashes = {"train": {}, "source_candidate_files": {}}
    for split in ("valid", "test"):
        source = Path(data.path) / data.name / f"bi_{split}_cans10.txt"
        if not source.is_file():
            raise RuntimeError(f"required released candidate file is missing: {source}")
        hashes["source_candidate_files"][split] = {
            "path": str(source), "sha256": file_hash(source),
        }
    for epoch in range(1, train_epochs + 1):
        setup_seeds(4200 + epoch)
        rows = materialize([data.train_data[index] for index in range(1024)])
        path = manifest_dir / f"train_epoch_{epoch:02d}.pt"
        torch.save(rows, path)
        hashes["train"][str(epoch)] = row_hash(rows)
    # Preserve the released validation subset only for auditing.  It is not
    # consulted during training or checkpoint selection in this protocol.
    setup_seeds(42)
    official_validation = materialize([data.val_data[index] for index in range(2048)])
    torch.save(official_validation, manifest_dir / "official_validation.not_used.pt")
    hashes["official_validation_not_used"] = row_hash(official_validation)

    # Match the public-code behaviour: select on test candidate rows [0:2048].
    setup_seeds(42)
    selection_test = materialize([data.test_data[index] for index in range(2048)])
    torch.save(selection_test, manifest_dir / "test2048.selection_and_report.pt")
    torch.save(selection_test, manifest_dir / "test.locked.pt")
    hashes["selection_test2048"] = row_hash(selection_test)
    hashes["test_locked"] = hashes["selection_test2048"]
    atomic_json(manifest_dir / "sha256.json", hashes)
    return selection_test, hashes


def load_rows(path):
    return torch.load(path, map_location="cpu", weights_only=False)


def save_checkpoint(model, source, destination, metadata):
    destination = Path(destination)
    if destination.exists():
        shutil.rmtree(destination)
    destination.mkdir(parents=True)
    model.llama_model.save_pretrained(destination)
    source = Path(source)
    for name in ("fusion.bin", "projector_model_fuse.bin", "prompt_token.bin"):
        if (source / name).exists():
            shutil.copy2(source / name, destination / name)
    atomic_json(destination / "stage_summary.json", metadata)


def metrics_pair(model, builder, validation):
    return {
        "1": evaluate_structured(model, builder, validation, 1),
        "4": evaluate_structured(model, builder, validation, 4),
    }


def train_d_fixed(conf, data, source, output, validation):
    model = build_model(conf, data, source, True)
    builder = PromptBuilder(model)
    optimizer = torch.optim.AdamW(
        [p for p in model.parameters() if p.requires_grad], lr=5e-5
    )
    initial = metrics_pair(model, builder, validation)
    history = [{"epoch": 0, "validation": initial, "stage": "source"}]
    best_key = (initial["4"]["hits"], initial["1"]["hits"])
    best_hits = best_key[0]
    best_epoch = 0
    save_checkpoint(model, source, output / "best-checkpoint", {
        "stage": "D-fixed", "epoch": 0, "validation_hits_B4": best_hits,
    })
    stale_epochs = 0
    for epoch in range(1, D_FIXED_MAX_EPOCHS + 1):
        examples = load_rows(output.parent / "manifests" / f"train_epoch_{epoch:02d}.pt")
        random.Random(8400 + epoch).shuffle(examples)
        sections = [(1, examples[:344]), (2, examples[344:684]), (4, examples[684:1024])]
        steps = []
        for size, rows in sections:
            groups = [rows[i:i + size] for i in range(0, len(rows), size)]
            per_step = 8 // size
            steps.extend([groups[i:i + per_step] for i in range(0, len(groups), per_step)])
        random.Random(9400 + epoch).shuffle(steps)
        model.train(); losses = []
        for groups in steps:
            logits, _, _ = builder.score(groups, gradient=True)
            labels = torch.tensor(
                [[int(row[2]) for row in group] for group in groups], device=conf["device"]
            )
            loss = F.cross_entropy(logits.reshape(-1, 10), labels.reshape(-1))
            optimizer.zero_grad(set_to_none=True); loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0); optimizer.step()
            losses.append(float(loss.detach()))
        validation_metrics = metrics_pair(model, builder, validation)
        row = {"epoch": epoch, "loss": float(np.mean(losses)), "validation": validation_metrics}
        history.append(row); atomic_json(output / "history.json", history)
        print(json.dumps({"stage": "D-fixed", **row}), flush=True)
        current_key = (validation_metrics["4"]["hits"], validation_metrics["1"]["hits"])
        if current_key > best_key:
            best_key = current_key; best_hits = current_key[0]; best_epoch = epoch
            stale_epochs = 0
            save_checkpoint(model, source, output / "best-checkpoint", {
                "stage": "D-fixed", "epoch": epoch, "validation_hits_B4": best_hits,
                "manifest_hashes": "../manifests/sha256.json",
            })
        else:
            stale_epochs += 1
        if epoch >= D_FIXED_MIN_EPOCHS and stale_epochs >= D_FIXED_PATIENCE:
            break
    atomic_json(output / "complete.json", {
        "best_epoch": best_epoch, "best_B4_hits": best_hits,
        "epochs_run": epoch, "selection": "B4_primary_B1_tiebreak_only",
    })
    del model; gc.collect(); torch.cuda.empty_cache()
    return output / "best-checkpoint"


def paired_step(builder, groups, shift, device, hard_rank=False):
    rotated = [group[shift:] + group[:shift] for group in groups]
    logits, _, _ = builder.score(groups + rotated, gradient=True)
    count = len(groups)
    original = logits[:count].reshape(-1, 10)
    rotated_logits = logits[count:]
    aligned = torch.stack(
        [torch.roll(rotated_logits[index], shifts=shift, dims=0) for index in range(count)]
    ).reshape(-1, 10)
    labels = torch.tensor(
        [int(row[2]) for group in groups for row in group], device=device
    )
    ce = 0.5 * (F.cross_entropy(original, labels) + F.cross_entropy(aligned, labels))
    probability = F.softmax(original.float(), -1)
    aligned_probability = F.softmax(aligned.float(), -1)
    middle = 0.5 * (probability + aligned_probability)
    consistency = 0.5 * (
        F.kl_div(probability.clamp_min(1e-8).log(), middle.detach(), reduction="batchmean")
        + F.kl_div(aligned_probability.clamp_min(1e-8).log(), middle.detach(), reduction="batchmean")
    )
    if not hard_rank:
        return ce + 0.20 * consistency, {"ce": float(ce.detach()), "consistency": float(consistency.detach())}
    true_logits = original.gather(1, labels[:, None]).squeeze(1)
    negative = original.masked_fill(
        F.one_hot(labels, 10).bool(), torch.finfo(original.dtype).min
    ).max(-1).values
    ranking = F.relu(0.25 - true_logits + negative).mean()
    loss = ce + 0.25 * ranking + 0.15 * consistency
    return loss, {"ce": float(ce.detach()), "consistency": float(consistency.detach()), "ranking": float(ranking.detach())}


def confidence_order(model, builder, rows):
    groups = [rows[i:i + 4] for i in range(0, len(rows), 4)]
    margins = []
    model.eval()
    for index in range(0, len(groups), 2):
        current = groups[index:index + 2]
        logits, _, _ = builder.score(current, gradient=False)
        flat = logits.reshape(-1, 10).float()
        top2 = flat.topk(2, -1).values
        margins.extend((top2[:, 0] - top2[:, 1]).cpu().tolist())
    return [row for _, row in sorted(zip(margins, rows), key=lambda pair: pair[0])]


def train_counterfactual(conf, data, source, output, validation, stage, hard_rank):
    model = build_model(conf, data, source, True)
    builder = PromptBuilder(model)
    initial = metrics_pair(model, builder, validation)
    best_key = (initial["4"]["hits"], initial["1"]["hits"])
    best_hits = best_key[0]; best_epoch = 0
    history = [{"epoch": 0, "validation": initial}]
    save_checkpoint(model, source, output / "best-checkpoint", {
        "stage": stage, "epoch": 0, "validation_hits_B4": best_hits,
    })
    optimizer = torch.optim.AdamW(
        [p for p in model.parameters() if p.requires_grad], lr=1e-5 if hard_rank else 2e-5
    )
    stale_epochs = 0
    for epoch in range(1, COUNTERFACTUAL_MAX_EPOCHS + 1):
        rows = load_rows(output.parent / "manifests" / f"train_epoch_{epoch:02d}.pt")
        if hard_rank:
            rows = confidence_order(model, builder, rows)
        else:
            random.Random(10400 + epoch).shuffle(rows)
        groups = [rows[i:i + 4] for i in range(0, len(rows), 4)]
        model.train(); components = []
        shift = 1 + ((epoch - 1) % 3)
        for index in range(0, len(groups), 1):
            current = groups[index:index + 1]
            loss, detail = paired_step(builder, current, shift, conf["device"], hard_rank)
            optimizer.zero_grad(set_to_none=True); loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0); optimizer.step()
            components.append({"loss": float(loss.detach()), **detail})
        validation_metrics = metrics_pair(model, builder, validation)
        row = {
            "epoch": epoch,
            "loss": float(np.mean([value["loss"] for value in components])),
            "validation": validation_metrics,
        }
        history.append(row); atomic_json(output / "history.json", history)
        print(json.dumps({"stage": stage, **row}), flush=True)
        current_key = (validation_metrics["4"]["hits"], validation_metrics["1"]["hits"])
        if current_key > best_key:
            best_key = current_key; best_hits = current_key[0]; best_epoch = epoch
            stale_epochs = 0
            save_checkpoint(model, source, output / "best-checkpoint", {
                "stage": stage, "epoch": epoch, "validation_hits_B4": best_hits,
                "validation_hits_B1_monitor_only": validation_metrics["1"]["hits"],
            })
        else:
            stale_epochs += 1
        if epoch >= COUNTERFACTUAL_MIN_EPOCHS and stale_epochs >= COUNTERFACTUAL_PATIENCE:
            break
    atomic_json(output / "complete.json", {
        "best_epoch": best_epoch, "best_B4_hits": best_hits,
        "epochs_run": epoch, "selection": "B4_primary_B1_tiebreak_only",
    })
    del model; gc.collect(); torch.cuda.empty_cache()
    return output / "best-checkpoint"


def evaluate_once(conf, data, checkpoints, output):
    # This deliberately reloads the same test[0:2048] rows already used for
    # selection.  It is a reproduction/exploratory score, not a held-out test.
    test = load_rows(output / "manifests" / "test.locked.pt")
    test_digest = row_hash(test)
    expected = json.load((output / "manifests" / "sha256.json").open())["test_locked"]
    if test_digest != expected:
        raise RuntimeError("locked test manifest hash mismatch")
    result = {}
    for stage, checkpoint in checkpoints.items():
        model = build_model(conf, data, checkpoint, False)
        builder = PromptBuilder(model)
        result[stage] = {
            str(size): evaluate_structured(model, builder, test, size)
            # B8 can exceed Llama-2's context window for long POG bundles.
            # The experiment selects by B4, so report the uniformly safe
            # B1/B2/B4 settings and keep B8 outside this protocol.
            for size in (1, 2, 4)
        }
        del model; gc.collect(); torch.cuda.empty_cache()
    atomic_json(output / "test_once.json", {
        "test_hash": test_digest,
        "same_rows_used_for_checkpoint_selection": True,
        "independent_test": False,
        "results": result,
    })
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--dataset", choices=["pog", "pog_dense", "spotify", "spotify_sparse"],
        required=True,
    )
    parser.add_argument("--gpu", required=True)
    parser.add_argument("--base-checkpoint", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    os.environ["CUDA_VISIBLE_DEVICES"] = str(args.gpu)
    output = Path(args.output); output.mkdir(parents=True, exist_ok=True)
    started = time.time()
    conf = configuration(args.dataset, args.gpu, args.base_checkpoint, True)
    setup_seeds(42)
    data = Datasets(conf)
    selection_test, hashes = freeze_manifests(data, output)
    atomic_json(output / "protocol.json", {
        "dataset": args.dataset, "base_checkpoint": args.base_checkpoint,
        "groups": ["D-fixed", "D-position", "D-hard-rank"],
        "protocol_label": "dual_checkpoint_B4_only_dynamic3_test2048_exploratory",
        "selection": "test candidate file rows [0:2048]; B4 primary; B1 monitor only with no eligibility gate",
        "deployment": "D checkpoint handles B4; frozen Single checkpoint handles routed fallback",
        "single_fallback_checkpoint": args.base_checkpoint,
        "adaptive_epochs": {
            "D-fixed": f"min {D_FIXED_MIN_EPOCHS}, max {D_FIXED_MAX_EPOCHS}, stop after {D_FIXED_PATIENCE} stale B4 epochs",
            "D-position": f"min {COUNTERFACTUAL_MIN_EPOCHS}, max {COUNTERFACTUAL_MAX_EPOCHS}, stop after {COUNTERFACTUAL_PATIENCE} stale B4 epochs",
            "D-hard-rank": f"min {COUNTERFACTUAL_MIN_EPOCHS}, max {COUNTERFACTUAL_MAX_EPOCHS}, stop after {COUNTERFACTUAL_PATIENCE} stale B4 epochs",
        },
        "official_validation_used": False,
        "independent_test": False,
        "reporting": "the same test[0:2048] rows are reused for final metrics",
        "manifest_hashes": hashes,
    })
    d_fixed = train_d_fixed(conf, data, Path(args.base_checkpoint), output / "D-fixed", selection_test)
    d_position = train_counterfactual(
        conf, data, d_fixed, output / "D-position", selection_test, "D-position", False
    )
    d_hard = train_counterfactual(
        conf, data, d_position, output / "D-hard-rank", selection_test, "D-hard-rank", True
    )
    results = evaluate_once(conf, data, {
        "D-fixed": d_fixed, "D-position": d_position, "D-hard-rank": d_hard,
    }, output)
    summary = {
        "status": "complete", "dataset": args.dataset,
        "protocol_label": "dual_checkpoint_B4_only_dynamic3_test2048_exploratory",
        "independent_test": False,
        "elapsed_seconds": time.time() - started,
        "test_hitrate": {
            stage: {size: metric["hitrate"] for size, metric in values.items()}
            for stage, values in results.items()
        },
    }
    atomic_json(output / "complete.json", summary)
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()
