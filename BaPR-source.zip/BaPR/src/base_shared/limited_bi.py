"""Run the existing BI stage within a 4 GiB PyTorch allocation budget."""
import datetime
import os
from pathlib import Path
import runpy
import sys
import traceback

import torch
from core import atomic

out = Path(sys.argv[sys.argv.index('--out') + 1])
torch.cuda.set_per_process_memory_fraction(
    4 * 1024 ** 3 / torch.cuda.get_device_properties(0).total_memory, 0)
atomic(out / 'bi_precompute.started.json', dict(
    pid=os.getpid(), time=datetime.datetime.now().astimezone().isoformat(),
    gpu=os.environ['CUDA_VISIBLE_DEVICES'], pytorch_memory_limit_gib=4,
    protocol='unchanged filtered-graph BI stage; validation selection'))
try:
    runpy.run_path(str(Path(__file__).with_name('fit_bi.py')), run_name='__main__')
    (out / 'bi_pretraining.exitcode').write_text('0\n')
except BaseException:
    atomic(out / 'bi_precompute.error.json', dict(traceback=traceback.format_exc()))
    (out / 'bi_pretraining.exitcode').write_text('1\n')
    raise
