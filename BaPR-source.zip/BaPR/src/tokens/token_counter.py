"""Count only IDs that the native prompt builder actually embeds."""
def counted_builder(base):
    class CountedBuilder(base):
        def __init__(self, model):
            super().__init__(model)
            self.text_tokens = 0
            self.bos_tokens = 0
            self.prompt_count = 0
        def text(self, value):
            embedded = super().text(value)
            self.text_tokens += int(embedded.shape[1])
            return embedded
        def pack(self, group):
            packed = super().pack(group)
            bos = int(self.model.bos_embeds.shape[0])
            self.text_tokens += bos
            self.bos_tokens += bos
            self.prompt_count += 1
            return packed
    return CountedBuilder
