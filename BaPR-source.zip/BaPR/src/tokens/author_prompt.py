# Bundle-MLLM prompt method; see licenses/Bundle-MLLM.txt.
def generate_prompt(self, input_, target_):
    if self.dataset_name[:7] == 'spotify':
        t_name = 'playlist continuation'
        b_name = 'music playlist'
        i_name = 'song'
    else:
        t_name = 'bundle construction'
        b_name = 'fashion outfit'
        i_name = 'fashion item'
    if 'Llama-2-7b-chat-hf' in self.llama_model_path:
        chat = [{'role': 'system', 'content': f'You are a helpful and honest assistant. The following are multiple choice questions about {t_name}. You should directly answer the question by choosing the letter of the correct option. Only provide the letter of your answer, without any explanation or mentioning the option content.'}, {'role': 'user', 'content': f'Given the partial {i_name}s: {input_}, which candidate {i_name} should be included into this {b_name}?\nOptions: {target_}\nYYour answer should indicate your choice with a single letter (e.g., “A,” “B,” “C,” etc.).'}, {'role': 'assistant', 'content': 'The answer is '}]
        return self.tokenizer.apply_chat_template(chat, tokenize=False).replace('<s>', '').replace('</s>', '')
    elif 'Llama-2-7b-hf' in self.llama_model_path:
        return f'You are a helpful and honest assistant. The following are multiple choice questions about {t_name}. You should directly answer the question by choosing the letter of the correct option. Only provide the letter of your answer, without any explanation or mentioning the option content. Question: Given the partial {b_name}: {input_}, which candidate {i_name} should be included into this {b_name}?\nOptions: {target_}\nYour answer should indicate your choice with a single letter (e.g., “A,” “B,” “C,” etc.).\nChoice: '
