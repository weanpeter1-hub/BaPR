"""Fit only reserved original-training questions; select on original validation."""
import statistics
from pathlib import Path
import torch
from core import RelationHead, head_features, fit_normalizer, head_loss, predict, metrics, atomic
from balanced import gain_balanced_loss

from data_roles import head_schedule
SEEDS = [20261028,20261029,20261030]
KEYS = ['logits','labels','features','graph']

def training_loss(score,base,y,mode,loss_mode,new_correct):
    if mode=='no_preserve':
        return head_loss(score,base,y,False,1.)[0]
    if loss_mode=='balanced':
        return gain_balanced_loss(score,base,y,new_correct,1.)
    return head_loss(score,base,y,True,1.)[0]


def checkpoint_choice(records):
    return max(records,key=lambda r:(r['validation']['hits'],-r['validation']['damages'],-r['step']))


def pool_choice(pools):
    return sorted(pools,key=lambda name:(-statistics.mean(r['validation']['hits'] for r in pools[name]),
        statistics.mean(r['validation']['damages'] for r in pools[name]),name))[0]


def describe(records, key):
    values = [r[key]['hits'] for r in records]
    return dict(hits=values,mean_hits=statistics.mean(values),sample_sd_hits=statistics.stdev(values),
        min_hits=min(values),max_hits=max(values),mean_hitrate=statistics.mean(r[key]['hitrate'] for r in records),
        mean_repairs=statistics.mean(r[key]['repairs'] for r in records),mean_damages=statistics.mean(r[key]['damages'] for r in records))


@torch.no_grad()
def score_all(head, features, base):
    return torch.cat([head(features[i:i+256],base[i:i+256]).cpu() for i in range(0,len(base),256)])


def feature_input(cache, mode='full'):
    return head_features(cache['features'],cache['graph'],cache['logits'],zero_graph=mode=='no_graph')


def train_one(training, validation, seed, out, source, pool, progress, mode='full', amplitude=1.5, preservation_multiplier=1.,new_correct=None,loss_mode="balanced",safety=.1):
    out.mkdir(parents=True)
    torch.manual_seed(seed)
    f = feature_input(training,mode)
    mean,std = fit_normalizer(f)
    f = ((f-mean)/std).to('cpu')
    fv = ((feature_input(validation,mode)-mean)/std).to('cpu')
    z,y = training['logits'].to('cpu'),training['labels'].to('cpu')
    zv = validation['logits'].to('cpu')
    head = RelationHead(amplitude=amplitude).to('cpu')
    opt = torch.optim.AdamW(head.parameters(),lr=3e-4,weight_decay=.01)
    gen = torch.Generator().manual_seed(seed)
    batches = iter([])
    history = []
    steps_per_epoch,milestones=head_schedule(len(f))
    for step in range(milestones[-1]+1):
        if step:
            idx = next(batches,None)
            if idx is None:
                batches = iter(torch.randperm(len(f),generator=gen).split(64));idx=next(batches)
            head.train();opt.zero_grad(set_to_none=True)
            score = head(f[idx],z[idx])
            loss = training_loss(score,z[idx],y[idx],mode,loss_mode,new_correct[idx])
            loss.backward();torch.nn.utils.clip_grad_norm_(head.parameters(),1.,error_if_nonfinite=True);opt.step()
        if step not in milestones:continue
        head.eval();sv=score_all(head,fv,zv)
        ck = out/f'head_step{step}.pt'
        torch.save(dict(state={k:v.detach().cpu().clone() for k,v in head.state_dict().items()},mean=mean,std=std,
            seed=seed,step=step,pool=pool,feature_mode=mode,preserve=mode!='no_preserve',source_checkpoint=str(source),feature_dim=57,amplitude=amplitude,preservation_multiplier=preservation_multiplier,
            safety=safety,training_device='cpu',optimizer_state=opt.state_dict(),rng=torch.get_rng_state(),batch_rng=gen.get_state(),training_rows=len(f),selection='validation',normalizer_fit='training_only',preservation_reduction=loss_mode),ck)
        torch.save(sv,out/f'validation_scores_step{step}.pt')
        rec=dict(seed=seed,amplitude=amplitude,preservation_multiplier=preservation_multiplier,feature_mode=mode,step=step,epoch=step/steps_per_epoch,pool=pool,checkpoint=str(ck),
            validation=metrics(validation['logits'],validation['labels'],predict(validation['logits'],sv,safety)))
        history.append(rec);atomic(out/'history.json',history)
        progress(phase='head_training',pool=pool,seed=seed,step=step,validation_hits=rec['validation']['hits'])
    best=checkpoint_choice(history)
    atomic(out/'selection.json',best)
    return best


def apply_selected(record, cache):
    payload=torch.load(record['checkpoint'],map_location='cpu',weights_only=True)
    f=(feature_input(cache,payload.get('feature_mode','full'))-payload['mean'])/payload['std']
    head=RelationHead(amplitude=payload['amplitude']).to('cpu');head.load_state_dict(payload['state']);head.eval()
    scores=score_all(head,f.to('cpu'),cache['logits'].to('cpu'))
    return scores,predict(cache['logits'],scores,payload['safety'])
