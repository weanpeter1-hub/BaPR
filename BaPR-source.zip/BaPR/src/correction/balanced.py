import torch
import torch.nn.functional as F
from core import head_loss,margin

def balanced_mean(values,new,old):
    groups=[values[mask].mean() for mask in (new,old) if mask.any()]
    return torch.stack(groups).mean() if groups else values.sum()*0

def gain_balanced_loss(score,base,labels,new_correct,preservation_multiplier=1.):
    original,terms=head_loss(score,base,labels,True,preservation_multiplier)
    correct=base.detach().argmax(-1).eq(labels)
    penalties=F.relu(margin(base.detach(),labels).clamp(.05,.5)-margin(score,labels))
    keep=balanced_mean(penalties,correct&new_correct,correct&~new_correct)
    return original+preservation_multiplier*.2*(keep-terms['keep'])
