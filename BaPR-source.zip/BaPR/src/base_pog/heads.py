"""Fit on original-training questions; select only from validation metrics."""
import statistics
from pathlib import Path
import torch
from core import RelationHead, head_features, fit_normalizer, head_loss, predict, metrics, atomic

MILESTONES = [0,320,640,1280,2560]
SEEDS = [20261028,20261029,20261030]
KEYS = ['logits','labels','features','graph']


def checkpoint_choice(records):
    return max(records,key=lambda r:(r['validation']['hits'],-r['validation']['damages'],-r['step']))


def pool_choice(pools):
    return sorted(pools,key=lambda name:(-statistics.mean(r['validation']['hits'] for r in pools[name]),
        statistics.mean(r['validation']['damages'] for r in pools[name]),name))[0]


def describe(records, key):
    values = [r[key]['hits'] for r in records]
    return dict(hits=values,mean_hits=statistics.mean(values),sample_sd_hits=statistics.stdev(values),
        min_hits=min(values),max_hits=max(values),mean_hitrate=statistics.mean(r[key]['hitrate'] for r in records),
        mean_repairs=statistics.mean(r[key]['repairs'] for r in records),mean_damages=statistics.mean(r[key]['damages'] for r in records))


@torch.no_grad()
def score_all(head, features, base):
    return torch.cat([head(features[i:i+256],base[i:i+256]).cpu() for i in range(0,len(base),256)])


def train_one(training, validation, seed, out, source, pool, progress):
    out.mkdir(parents=True)
    torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)
    f = head_features(training['features'],training['graph'],training['logits'])
    mean,std = fit_normalizer(f)
    f = ((f-mean)/std).cuda()
    fv = ((head_features(validation['features'],validation['graph'],validation['logits'])-mean)/std).cuda()
    z,y = training['logits'].cuda(),training['labels'].cuda()
    zv = validation['logits'].cuda()
    head = RelationHead().cuda()
    opt = torch.optim.AdamW(head.parameters(),lr=3e-4,weight_decay=.01)
    gen = torch.Generator().manual_seed(seed)
    batches = iter([])
    history = []
    for step in range(2561):
        if step:
            idx = next(batches,None)
            if idx is None:
                batches = iter(torch.randperm(len(f),generator=gen).split(64));idx=next(batches)
            head.train();opt.zero_grad(set_to_none=True)
            score = head(f[idx],z[idx]);loss,_=head_loss(score,z[idx],y[idx],True)
            loss.backward();torch.nn.utils.clip_grad_norm_(head.parameters(),1.,error_if_nonfinite=True);opt.step()
        if step not in MILESTONES:continue
        head.eval();sv=score_all(head,fv,zv)
        ck = out/f'head_step{step}.pt'
        torch.save(dict(state={k:v.detach().cpu().clone() for k,v in head.state_dict().items()},mean=mean,std=std,
            seed=seed,step=step,pool=pool,source_checkpoint=str(source),feature_dim=57,amplitude=1.5,
            safety=.1,training_rows=len(f),selection='validation',normalizer_fit='training_only'),ck)
        torch.save(sv,out/f'validation_scores_step{step}.pt')
        rec=dict(seed=seed,step=step,epoch=step*64/len(f),pool=pool,checkpoint=str(ck),
            validation=metrics(validation['logits'],validation['labels'],predict(validation['logits'],sv)))
        history.append(rec);atomic(out/'history.json',history)
        progress(phase='head_training',pool=pool,seed=seed,step=step,validation_hits=rec['validation']['hits'])
    best=checkpoint_choice(history)
    atomic(out/'selection.json',best)
    return best


def apply_selected(record, cache):
    payload=torch.load(record['checkpoint'],map_location='cpu',weights_only=True)
    f=(head_features(cache['features'],cache['graph'],cache['logits'])-payload['mean'])/payload['std']
    head=RelationHead().cuda();head.load_state_dict(payload['state']);head.eval()
    scores=score_all(head,f.cuda(),cache['logits'].cuda())
    return scores,predict(cache['logits'],scores)
