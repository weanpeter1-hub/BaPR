"""Reserve bundle identities before any new BI embedding/task fitting."""
import json
import shutil
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import scipy.sparse as sp
import torch
from core import atomic, file_hash
from utils import BundleTrainDataset, list2pairs

def read_bundles(path):
    rows={}
    for line in Path(path).read_text().splitlines():
        xs=[int(x.strip()) for x in line.split(',')]
        rows[xs[0]]=set(xs[1:])
    return rows

def filter_bundles(bundles, reserved, base_ids):
    if reserved & base_ids:raise ValueError('Reserved and base bundles overlap')
    if not (reserved|base_ids)<=bundles.keys():raise ValueError('Bundle outside original training split')
    return {bid:items for bid,items in bundles.items() if bid not in reserved}

def normalized_adjacency(pairs, n_left, n_items):
    a=pairs[:,0];b=pairs[:,1]+n_left
    row=torch.cat([a,b]);col=torch.cat([b,a]);n=n_left+n_items
    deg=torch.bincount(row,minlength=n).float().clamp_min(1)
    values=(deg[row]*deg[col]).rsqrt()
    return torch.sparse_coo_tensor(torch.stack([row,col]),values,(n,n)).coalesce()

def prepare(project,out):
    out=Path(out);dst=out/'data/pog';dst.mkdir(parents=True)
    source=Path(project)/'datasets/pog'
    manifests=out/'manifests';manifests.mkdir()
    historical=Path(project)/'experiments/d_dynamic3_parallel_20260915/pog/manifests'
    original=Path(project)/'experiments/pog_oldfixed_ce_control_20260917/manifests'
    extra=Path(project)/'experiments/relation_training_subset_search_20261106/manifests/pog_extra2026110601.pt'
    reserved_rows=torch.load(extra,map_location='cpu',weights_only=False)
    train=torch.load(original/'train_epoch_01.pt',map_location='cpu',weights_only=False)
    reserved={int(r[0]) for r in reserved_rows};base_ids={int(r[0]) for r in train}
    assert len(reserved_rows)==len(reserved)==2048 and len(base_ids)==1024
    all_bundles=read_bundles(source/'bi_train.txt')
    kept=filter_bundles(all_bundles,reserved,base_ids)
    (dst/'bi_train.txt').write_text(''.join(', '.join(map(str,[b]+sorted(v)))+'\n' for b,v in sorted(kept.items())))
    for name in ['count.json','item_info.json','ui_full.txt','content_feature.pt','description_feature.pt','item_cf_feature.pt']:
        (dst/name).symlink_to(source/name)
    shutil.copy2(extra,manifests/'correction2048.pt')
    shutil.copy2(original/'train_epoch_01.pt',manifests/'train1024.pt')
    shutil.copy2(original/'official_validation.not_used.pt',manifests/'validation2048.pt')
    # Byte-copy only: test rows are deserialized after the final selection lock.
    shutil.copy2(original/'test.locked.pt',manifests/'test2048.pt')
    for epoch in range(1,31):
        shutil.copy2(historical/f'train_epoch_{epoch:02d}.pt',manifests/f'train_epoch_{epoch:02d}.pt')
    record=dict(original_training_bundles=len(all_bundles),retained_graph_bundles=len(kept),
        reserved_bundles=sorted(reserved),base_training_bundles=sorted(base_ids),
        original_edges=sum(map(len,all_bundles.values())),retained_edges=sum(map(len,kept.values())),
        reserved_edges=sum(len(all_bundles[b]) for b in reserved),
        original_graph_sha256=file_hash(source/'bi_train.txt'),filtered_graph_sha256=file_hash(dst/'bi_train.txt'),
        reservation_source=str(extra),selection='fixed existing pool601, no new pool search',
        original_cf_preserved=True,cf_scope='Independent user-item representation; not a claim of unseen item identities',
        original_bi_asset_used_as_initialization=False,correction_training_rows=2048)
    atomic(out/'data_boundary.json',record)
    return record

def load_data(conf):
    path=Path(conf['data_path'])/'pog'
    counts=json.loads((path/'count.json').read_text());nu,nb,ni=[counts[k] for k in ['#U','#B','#I']]
    pairs=list2pairs(path/'bi_train.txt');uip=list2pairs(path/'ui_full.txt')
    bi=sp.csr_matrix((np.ones(len(pairs)),(pairs[:,0],pairs[:,1])),shape=(nb,ni))
    ui=sp.csr_matrix((np.ones(len(uip)),(uip[:,0],uip[:,1])),shape=(nu,ni))
    features=tuple(torch.load(path/name,map_location=conf['device'],weights_only=False).detach()
        for name in ['content_feature.pt','description_feature.pt','item_cf_feature.pt','pog_LightGCN_bi_feature.pt'])
    sampler=BundleTrainDataset(conf,pairs,bi,features,nb,None,None,1)
    conf.update(num_users=nu,num_bundles=nb,num_items=ni)
    return SimpleNamespace(num_users=nu,num_bundles=nb,num_items=ni,graphs=[ui,bi,bi],
        features=features,item_info=json.loads((path/'item_info.json').read_text()),train_data=sampler)

def configuration(project,out,mode='text',parent=None):
    import yaml
    conf=yaml.safe_load((Path(project)/'config.yaml').read_text())['pog']
    conf.update(dataset='pog',data_path=str(Path(out)/'data'),device=torch.device('cuda:0'),
        base_model=str(Path(project).parent/'llama-2-7b-hf'),pretrain_model_path=str(parent) if parent else '',
        from_pretrain=parent is not None,mode=mode,few_shot=1024,toy_eval=2048,num_token=5,num_cans=10,
        soft_prompt=True,del_sp=(mode!='text'),train_lora=True,components='',sp_guided=False,sp_sg=False,
        batch_size_train=16,batch_size_test=16,num_workers=0,active_modalities=['content','bi','cf'])
    return conf
