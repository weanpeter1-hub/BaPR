"""Symmetric validation-only selection for the complete paired systems."""
import statistics

LLM_SEEDS = [20261028]
HEAD_SEEDS = [20261028, 20261029, 20261030]
MODES = ['repeat_ce', 'mixed_dual']

def choose_system(cases):
    def key(case):
        heads = case['heads']
        return (statistics.mean(h['validation']['hits'] for h in heads),
            -statistics.mean(h['validation']['damages'] for h in heads),
            -case['source']['step'])
    case = max(cases, key=key)
    head = max(case['heads'], key=lambda h: (h['validation']['hits'],
        -h['validation']['damages'], -h['step'], -h['seed']))
    return dict(case, head=head, selection='mean corrected validation hits across three head seeds; then fewer damages; earlier LLM step')

def collect_locks(out, read_json):
    return {str(seed): read_json(out/f'llm_seed{seed}/locked_selection.json') for seed in LLM_SEEDS}
