"""Run the recorded base stages in a prepared runtime."""
import argparse,json,subprocess,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--dataset',required=True)
p.add_argument('--runtime',type=Path,default=ROOT/'runtime')
p.add_argument('--stage',choices=['relations','text','multimodal','adaptation'],required=True)
a=p.parse_args();run=a.runtime.resolve()/'project'/a.dataset;code=run/'code'
commands={'relations':['fit_bi.py'],'text':['single.py','--stage','single_text'],
          'multimodal':['single.py','--stage','single_multimodal'],'adaptation':['adaptation.py']}
if a.stage=='adaptation' and not (run/'single_multimodal/selection.json').exists():
    dest=run/'single_multimodal';dest.mkdir()
    record=json.loads((ROOT/'configs/stages'/a.dataset/'single_multimodal/selection.json').read_text())
    record['checkpoint']=str(ROOT/'checkpoints'/a.dataset/'single_multimodal')
    (dest/'selection.json').write_text(json.dumps(record,indent=2)+'\n')
command=commands[a.stage]
subprocess.run([sys.executable,'-u',str(code/command[0]),*command[1:],'--out',str(run)],cwd=run.parent,check=True)
