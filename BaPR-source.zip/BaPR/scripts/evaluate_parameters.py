"""Recompute parameter-figure validation statistics from saved heads."""
import json,sys,statistics
from pathlib import Path
import torch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src/correction'))
from core import RelationHead,head_features,predict,metrics
torch.set_num_threads(2)
data=json.loads((ROOT/'results/parameter_data.json').read_text());rows=[]
for point in data['curves']:
    results=[]
    for ck,folder in zip(point['head_checkpoints'],point['caches']):
        c=torch.load(ROOT/folder/'validation.pt',map_location='cpu',weights_only=False)
        h=torch.load(ROOT/ck,map_location='cpu',weights_only=True)
        x=head_features(c['features'],c['graph'],c['logits'])
        x=(x-h['mean'])/h['std'];model=RelationHead(amplitude=h['amplitude']).eval();model.load_state_dict(h['state'])
        with torch.no_grad():scores=torch.cat([model(x[i:i+256],c['logits'][i:i+256]) for i in range(0,len(x),256)])
        gate=point['x'] if point['axis']=='gate' else .1
        results.append(metrics(c['logits'],c['labels'],predict(c['logits'],scores,gate)))
    row={'dataset':point['dataset'],'axis':point['axis'],'x':point['x'],
         'head_hits':[v['hits'] for v in results],'head_damages':[v['damages'] for v in results],
         'mean_hr_percent':100*statistics.mean(v['hitrate'] for v in results),
         'sample_sd_hr_percent':100*statistics.stdev(v['hitrate'] for v in results)}
    rows.append(row)
out=ROOT/'generated';out.mkdir(exist_ok=True)
(out/'parameter_evaluation.json').write_text(json.dumps(rows,indent=2)+'\n');print(out/'parameter_evaluation.json')
