from pathlib import Path
import json, sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

W=Path(__file__).resolve().parents[1]
j=json.loads((W/'results/figure_data.json').read_text())
F=W/'generated/figures';F.mkdir(parents=True,exist_ok=True)
BLUE='#397DA5'; GREEN='#51876B'; CORAL='#C97462'; GRAY='#929AA2'; INK='#27323A'
names={'pog':'POG','pog_dense':'POG dense','spotify':'Spotify','spotify_sparse':'Spotify sparse'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':9,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65,'axes.edgecolor':GRAY,'text.color':INK,'axes.labelcolor':INK,'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})
def save(fig,name):
    for ext in ['pdf','svg','png']:
        fig.savefig(F/(name+'.'+ext),dpi=240,bbox_inches='tight',pad_inches=.06)
    plt.close(fig)

fig,axs=plt.subplots(1,4,figsize=(7.2,2.4),layout='constrained')
for ax,(d,r) in zip(axs,j['dual'].items()):
    x,y=r['without'],r['full']; delta=y-x
    ax.plot([x,y],[-.03,.03],color=GRAY,lw=1.8)
    ax.scatter(x,-.03,marker='s',s=43,color=GRAY,zorder=3)
    ax.scatter(y,.03,s=45,color=BLUE,zorder=4)
    ax.annotate(f'{x:.2f}%',(x,-.03),xytext=(0,-22),textcoords='offset points',ha='center',fontsize=8,color='#626D76')
    ax.annotate(f'{y:.2f}%',(y,.03),xytext=(0,15),textcoords='offset points',ha='center',fontsize=8,color=BLUE)
    ax.set_title(names[d]+'\n'+f'{delta:+.2f} pp'); ax.set_xlim(min(x,y)-.28,max(x,y)+.28)
    ax.set_ylim(-.6,.6);ax.set_yticks([]);ax.spines['left'].set_visible(False)
    ax.set_xlabel('Test HR (%)');ax.grid(axis='x',color='#DCE2E6',lw=.6);ax.xaxis.set_major_locator(plt.MaxNLocator(3))
fig.legend(handles=[Line2D([],[],marker='s',ls='',color=GRAY,label='Without dual views + correction'),Line2D([],[],marker='o',ls='',color=BLUE,label='Dual views + correction')],loc='outside lower center',ncol=2,frameon=False,fontsize=8)
save(fig,'bapr_dual_comparison_pog_rho2_20261110')

fig,axs=plt.subplots(1,4,figsize=(7.2,2.55),layout='constrained')
for ax,(d,m) in zip(axs,j['full'].items()):
    values=[m['repairs'],m['damages'],m['net_gain']]
    ax.bar(range(3),values,width=.6,color=[BLUE,CORAL,GREEN],zorder=3)
    for x,v in enumerate(values):ax.text(x,v+7,str(v),ha='center',va='bottom',fontsize=8)
    ax.set_xticks(range(3),['Repair','Damage','Net']);ax.set_ylim(0,385);ax.grid(axis='y',color='#DCE2E6',lw=.6)
    ax.set_title(names[d]+'\n'+f"{m['base_hits']/2048*100:.2f}% → {m['hitrate']*100:.2f}%",pad=8)
    if d=='pog':ax.set_ylabel('Queries')
save(fig,'bapr_correction_outcomes_pog_rho2_20261110')
print('Saved two vector PDF figures with selected POG rho2/head29 panels.')
