"""Regenerate the final tables from recorded measurements, without training."""
from pathlib import Path
import json,csv

ROOT=Path(__file__).resolve().parents[1]
cfg=json.loads((ROOT/'configs/experiments.json').read_text());datasets=list(cfg)
out=ROOT/'generated/tables';out.mkdir(parents=True,exist_ok=True)
def save(name,rows):
    with (out/(name+'.csv')).open('w',newline='') as f:csv.writer(f).writerows(rows)
    text='| '+' | '.join(str(x) for x in rows[0])+' |\n'
    text+='|'+'|'.join([' --- ']*len(rows[0]))+'|\n'
    text+=''.join('| '+' | '.join(str(x) for x in r)+' |\n' for r in rows[1:])
    (out/(name+'.md')).write_text(text)
base=json.loads((ROOT/'results/published_baselines.json').read_text())
main=[['Method',*datasets]]+[[name,*[f'{v:.4f}' for v in values]] for name,values in base['scores'].items()]
main.append(['BaPR',*[f"{cfg[d]['main']['test']['hitrate']:.4f}" for d in datasets]])
main.append(['Relative improvement (%)',*[f"{100*(cfg[d]['main']['test']['hitrate']/base['scores']['Bundle-MLLM'][i]-1):.2f}" for i,d in enumerate(datasets)]])
save('main',main)
rows=[['Condition',*datasets]]
for role in ['without_dual','full']:
    rows.append([role,*[f"{100*cfg[d][role]['test']['hitrate']:.2f}" for d in datasets]])
rows.append(['Difference (percentage points)',*[f"{100*(cfg[d]['full']['test']['hitrate']-cfg[d]['without_dual']['test']['hitrate']):+.2f}" for d in datasets]])
save('dual_ablation',rows)
save('internal_ablation',[['Condition',*datasets]]+[[role,*[f"{100*cfg[d][role]['test']['hitrate']:.2f}" for d in datasets]]
    for role in ['full','without_relations','without_preservation','without_gate']])
adapt=json.loads((ROOT/'results/adaptation.json').read_text())
save('batch_adaptation',[['Condition',*datasets]]+[[role,*[f"{100*adapt[d][role]['hits']/adapt[d][role]['samples']:.2f}" for d in datasets]] for role in ['before','after']])
shutil_src=ROOT/'results/token_comparison.csv'
(out/'tokens.csv').write_bytes(shutil_src.read_bytes())
print(out)
