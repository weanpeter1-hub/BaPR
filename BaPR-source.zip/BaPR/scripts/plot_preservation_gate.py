from pathlib import Path
import json
import math
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator

W=Path(__file__).resolve().parents[1]
j=json.loads((W/'results/parameter_data.json').read_text())
out=W/'generated/figures';out.mkdir(parents=True,exist_ok=True)
D=j['datasets'];name=lambda d:d.replace('_',' ')
BLUE='#397DA5';GREEN='#51876B';CORAL='#C97462';GRAY='#929AA2';INK='#27323A'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':9,
 'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'axes.spines.top':False,
 'axes.spines.right':False,'axes.linewidth':.65,'axes.edgecolor':GRAY,
 'text.color':INK,'axes.labelcolor':INK,'xtick.color':INK,'ytick.color':INK,
 'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white',
 'grid.color':'#DCE2E6','grid.linewidth':.6})
damage_max=math.ceil(max(p['damage_mean']+p['damage_sd'] for p in j['curves'] if p['axis']=='amplitude')/20)*20
rows=[('amplitude','mean','sd',r'Residual bound $\rho$','Validation HR (%)',BLUE),
      ('amplitude','damage_mean','damage_sd',r'Residual bound $\rho$','Damaged queries',CORAL),
      ('preservation','mean','sd',r'Preservation weight $\kappa$','Validation HR (%)',GREEN),
      ('gate','mean','sd',r'Switching margin $\gamma_{sw}$','Validation HR (%)',CORAL)]

def make(nrows,stem,height):
    fig,axs=plt.subplots(nrows,4,figsize=(7.3,height),layout='constrained')
    for r,(axis,metric,sdfield,label,ylabel,color) in enumerate(rows[:nrows]):
        for c,ds in enumerate(D):
            ax=axs[r,c]
            points=[p for p in j['curves'] if p['dataset']==ds and p['axis']==axis]
            x=[p['x'] for p in points];y=[p[metric] for p in points];sd=[p[sdfield] for p in points]
            marker='s--' if metric=='damage_mean' else 'o-'
            ax.errorbar(x,y,yerr=sd,fmt=marker,color=color,capsize=2,lw=1.2,ms=3,zorder=3)
            ax.set_xlabel(label);ax.grid(axis='y',zorder=0);ax.margins(x=.08,y=.18)
            if r==0: ax.set_title(name(ds),pad=9)
            if c==0: ax.set_ylabel(ylabel)
            if axis=='amplitude':
                ax.set_xlim(.2,8.3);ax.set_xticks([.5,2,4,6,8]);ax.set_xticklabels(['0.5','2','4','6','8'])
            else:
                ax.set_xticks(x);ax.set_xticklabels([f'{v:g}' for v in x])
            if metric=='damage_mean':
                ax.set_ylim(0,damage_max);ax.yaxis.set_major_locator(MaxNLocator(4,integer=True))
            else:
                ax.yaxis.set_major_locator(MaxNLocator(4))
    for ext in ['pdf','svg','png']:
        fig.savefig(out/(stem+'.'+ext),dpi=250,bbox_inches='tight',pad_inches=.08)
    plt.close(fig)

rows=rows[2:]
make(2,'bapr_preservation_gate_20261110',3.45)
print(out)
