"""Matched native and upstream prompt serialization; no LLM inference."""
import argparse,json,sys
from pathlib import Path
from types import SimpleNamespace,MethodType
import torch
from transformers import AutoTokenizer

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(ROOT/'src/base_shared'),str(ROOT/'src/base_shared/legacy'),str(ROOT/'src/tokens')]
from model_spotify_eval import BundleMLLM
from batch_rank_s3 import PromptBuilder
from token_counter import counted_builder
from author_prompt import generate_prompt
from core import public_rows

p=argparse.ArgumentParser();p.add_argument('--data-root',type=Path,required=True)
p.add_argument('--tokenizer',required=True);p.add_argument('--dataset',default='all');a=p.parse_args()
tokenizer=AutoTokenizer.from_pretrained(a.tokenizer,padding_side='left')
tokenizer.add_bos_token=False;tokenizer.add_prefix_space=False;torch.set_num_threads(2)
all_results={};CountedBuilder=counted_builder(PromptBuilder)
for ds in ['pog','pog_dense','spotify','spotify_sparse']:
    if a.dataset not in ['all',ds]:continue
    path=ROOT/'data'/ds
    model=SimpleNamespace(dataset_name=ds,device=torch.device('cpu'),tokenizer=tokenizer,
        option_token_ids=[tokenizer(chr(65+i),add_special_tokens=False).input_ids[-1] for i in range(10)],
        num_item=json.loads((path/'count.json').read_text())['#I'],text_format='artist_track_album',
        item_info=json.loads((a.data_root/ds/'item_info.json').read_text()),bos_embeds=torch.zeros(1,1),
        prompt_token=SimpleNamespace(weight=torch.zeros(1,1)),fusion=lambda x,p:torch.zeros(*x.shape,1),
        projector=lambda x:x,_embed_tokens=lambda ids:torch.zeros(len(ids),1),llama_model_path='Llama-2-7b-hf')
    model._get_caption=MethodType(BundleMLLM._get_caption,model)
    model.generate_prompt=MethodType(generate_prompt,model)
    rows=torch.load(path/'manifests/test2048.pt',map_location='cpu',weights_only=False)
    totals={}
    for b in [1,2,4]:
        builder=CountedBuilder(model)
        for offset in range(0,len(rows),8):
            batch=public_rows(rows[offset:offset+8])
            for i in range(0,len(batch),b):builder.pack(batch[i:i+b])
        totals[str(b)]=builder.text_tokens
    external=0
    for row in rows:
        context=[int(v) for v in row[1] if int(v)!=model.num_item];candidates=[int(v) for v in row[3]]
        given=''.join(f'{i+1}. {model._get_caption(x)}, <Feature>; ' for i,x in enumerate(context))
        target=''.join(f'{chr(65+i)}. {model._get_caption(x)}, <Feature>; ' for i,x in enumerate(candidates))
        text=model.generate_prompt(given,target)
        external+=1+sum(min(len(tokenizer(t,add_special_tokens=False).input_ids),2048) for t in text.split('<Feature>'))
    all_results[ds]={'samples':len(rows),'BaPR_total':totals,'author_template_total':external,
                     'BaPR_per_query':{k:v/len(rows) for k,v in totals.items()},'author_template_per_query':external/len(rows)}
    print(ds,all_results[ds])
out=ROOT/'generated';out.mkdir(exist_ok=True)
(out/'token_counts.json').write_text(json.dumps(all_results,indent=2)+'\n')
