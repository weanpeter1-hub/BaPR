"""Materialize the recorded layout from bundled splits and public item assets."""
import argparse,json,shutil
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--dataset',required=True)
p.add_argument('--data-root',type=Path,required=True);p.add_argument('--llama',type=Path,required=True)
p.add_argument('--runtime',type=Path,default=ROOT/'runtime');a=p.parse_args()
runtime=a.runtime.resolve();project=runtime/'project';run=project/a.dataset
run.mkdir(parents=True);code=run/'code'
shutil.copytree(ROOT/'src/base_shared',code)
variant={'pog':'base_pog','spotify':'base_spotify'}.get(a.dataset)
if variant:shutil.copytree(ROOT/'src'/variant,code,dirs_exist_ok=True)
shutil.copy2(ROOT/'configs/backbone.yaml',project/'config.yaml')
link=runtime/'llama-2-7b-hf'
if not link.exists():link.symlink_to(a.llama.resolve(),target_is_directory=True)
shutil.copy2(ROOT/'data'/a.dataset/'data_boundary.json',run/'data_boundary.json')
shutil.copytree(ROOT/'data'/a.dataset/'manifests',run/'manifests')
aliases={'selection.pt':'validation2048.pt','correction.pt':'correction2048.pt'}
for one,two in aliases.items():
    folder=run/'manifests'
    if not (folder/one).exists():(folder/one).symlink_to(two)
    if not (folder/two).exists():(folder/two).symlink_to(one)
data=run/'data'/a.dataset;data.mkdir(parents=True)
for name in ['bi_train.txt','count.json',a.dataset+'_LightGCN_bi_feature.pt']:
    shutil.copy2(ROOT/'data'/a.dataset/name,data/name)
for name in ['content_feature.pt','description_feature.pt','item_cf_feature.pt','ui_full.txt','item_info.json']:
    (data/name).symlink_to((a.data_root/a.dataset/name).resolve())
print('Project:',project);print('Run:',run);print('Source:',code)
