"""Refit one final correction condition; validation selects the checkpoint."""
import argparse,json,sys
from pathlib import Path
import torch

ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--dataset',required=True)
p.add_argument('--row',default='full',choices=['main','full','without_dual','without_relations','without_preservation'])
p.add_argument('--device',default='cpu',choices=['cpu','cuda']);p.add_argument('--output',type=Path)
p.add_argument('--cache',type=Path);p.add_argument('--parent-cache',type=Path)
a=p.parse_args();torch.set_num_threads(2)
cfg=json.loads((ROOT/'configs/experiments.json').read_text())[a.dataset];record=cfg[a.row]
payload=torch.load(ROOT/record['checkpoint'],map_location='cpu',weights_only=True)
family=payload.get('preservation_reduction','native')
balanced=family=='balanced'
sys.path.insert(0,str(ROOT/'src'/('correction' if balanced else 'correction_pog')))
from heads import train_one
cache=a.cache or ROOT/record['cache'];train=torch.load(cache/'train.pt',map_location='cpu',weights_only=False)
validation=torch.load(cache/'validation.pt',map_location='cpu',weights_only=False)
output=a.output or ROOT/'generated/refits'/a.dataset/a.row
kwargs=dict(mode=payload.get('feature_mode','full'),amplitude=payload['amplitude'],
            preservation_multiplier=payload.get('preservation_multiplier',1.))
if balanced:
    parent=torch.load(a.parent_cache or ROOT/'data/cache'/a.dataset/'parent/train.pt',map_location='cpu',weights_only=False)
    kwargs.update(loss_mode='balanced',new_correct=parent['logits'].argmax(-1).ne(train['labels'])&train['logits'].argmax(-1).eq(train['labels']),safety=record['gate'])
else:kwargs['device']=a.device
selected=train_one(train,validation,record['seed'],output,'bundled frozen base',
    'reserved_original_training2048',lambda **x:print(json.dumps(x),flush=True),**kwargs)
print(json.dumps(selected,indent=2))
