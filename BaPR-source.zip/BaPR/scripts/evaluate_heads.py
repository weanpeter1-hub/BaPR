"""Evaluate final saved heads on fixed native feature caches (no LLM call)."""
import argparse, json, sys
from pathlib import Path
import torch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src/correction'))
from core import RelationHead,head_features,predict,metrics

def evaluate(record, root=ROOT):
    cache=torch.load(root/record['cache']/'test.pt',map_location='cpu',weights_only=False)
    payload=torch.load(root/record['checkpoint'],map_location='cpu',weights_only=True)
    features=head_features(cache['features'],cache['graph'],cache['logits'],
                           zero_graph=payload.get('feature_mode')=='no_graph')
    features=(features-payload['mean'])/payload['std']
    head=RelationHead(amplitude=payload['amplitude']).eval()
    head.load_state_dict(payload['state'])
    with torch.no_grad():
        scores=torch.cat([head(features[i:i+256],cache['logits'][i:i+256])
                          for i in range(0,len(features),256)])
    return metrics(cache['logits'],cache['labels'],predict(cache['logits'],scores,record['gate']))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--dataset',default='all')
    p.add_argument('--row',default='all');p.add_argument('--root',type=Path,default=ROOT)
    a=p.parse_args();torch.set_num_threads(2)
    configs=json.loads((a.root/'configs/experiments.json').read_text());results={}
    for ds,rows in configs.items():
        if a.dataset not in ['all',ds]:continue
        results[ds]={}
        for row,record in rows.items():
            if 'checkpoint' not in record or a.row not in ['all',row]:continue
            result=evaluate(record,a.root)
            result['recorded_hits']=record['test']['hits']
            result['difference_hits']=result['hits']-record['test']['hits']
            results[ds][row]=result
            print(ds,row,result['hits'],f"{100*result['hitrate']:.4f}%",'difference',result['difference_hits'])
    out=a.root/'generated';out.mkdir(exist_ok=True)
    (out/'head_evaluation.json').write_text(json.dumps(results,indent=2)+'\n')
