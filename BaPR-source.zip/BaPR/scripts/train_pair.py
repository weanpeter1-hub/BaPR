"""Run one recorded Repeat/Dual pair, without launching other seed searches."""
import argparse,json,subprocess,sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--dataset',required=True)
p.add_argument('--runtime',type=Path,default=ROOT/'runtime');p.add_argument('--seed',type=int)
p.add_argument('--output',type=Path)
a=p.parse_args();source=a.runtime.resolve()/'project'/a.dataset
config=json.loads((ROOT/'configs/experiments.json').read_text())[a.dataset]['configuration']
seed=a.seed if a.seed is not None else config['llm_seed']
out=(a.output or source/'paired').resolve();out.mkdir()
if not (source/'batch_adaptation/selection.json').exists():
    dest=source/'batch_adaptation';dest.mkdir()
    record=json.loads((ROOT/'configs/stages'/a.dataset/'batch_adaptation/selection.json').read_text())
    record['checkpoint']=str(ROOT/'checkpoints'/a.dataset/'batch_adaptation')
    (dest/'selection.json').write_text(json.dumps(record,indent=2)+'\n')
child=out/f'llm_seed{seed}';child.mkdir()
for dest in [out,child]:
    for name in ['data','manifests','data_boundary.json']:
        (dest/name).symlink_to(source/name,target_is_directory=name!='data_boundary.json')
for phase in ['parent','fit']:
    subprocess.run([sys.executable,'-u',str(source/'code/seed_run.py'),'--source',str(source),
        '--out',str(out),'--seed',str(seed),'--phase',phase],cwd=source.parent,check=True)
print('Pair models and correction/validation features:',child)
print('This command does not run the final test split.')
