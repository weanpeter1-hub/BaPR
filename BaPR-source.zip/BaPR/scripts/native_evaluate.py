"""Fresh native B4 inference using a materialized runtime and selected weights."""
import argparse,importlib.util,json,sys
from pathlib import Path
import torch
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--dataset',required=True)
p.add_argument('--runtime',type=Path,default=ROOT/'runtime');p.add_argument('--condition',choices=['before','after','dual','repeat'],default='dual')
p.add_argument('--batch',type=int,choices=[1,2,4],default=4);p.add_argument('--head-row',default='main')
p.add_argument('--checkpoint',type=Path);p.add_argument('--head-checkpoint',type=Path)
a=p.parse_args();run=a.runtime.resolve()/'project'/a.dataset;sys.path.insert(0,str(run/'code'))
from batch_and_head import configuration,load_data,BundleMLLM,setup_seeds,restore,evaluate,BundleGraph,public_rows
checkpoint=ROOT/'checkpoints'/a.dataset/{'before':'single_multimodal','after':'batch_adaptation','dual':'dual','repeat':'repeat'}[a.condition]
if a.dataset=='pog' and a.condition=='repeat':checkpoint=ROOT/'checkpoints/pog/batch_adaptation'
if a.checkpoint:checkpoint=a.checkpoint.resolve()
setup_seeds(42);torch.set_num_threads(2)
conf=configuration(run.parent,run,'text+mm',checkpoint);conf['del_sp']=False
conf.update(training_stage='joint',fast_candidate_inference=True,disable_candidate_logit_pruning=False,
            uncertainty_gate_power=0.,compatibility_temperature=.1,base_margin=.2,hardness_margin_scale=.3,text_format='artist_track_album')
data=load_data(conf);model=BundleMLLM(conf,data.graphs,data.features,data.item_info,is_training=True).to(conf['device'])
model.option_token_ids=[model.tokenizer(chr(65+i),add_special_tokens=False).input_ids[-1] for i in range(10)]
restore(model,checkpoint);model.eval().requires_grad_(False)
rows=torch.load(run/'manifests/test2048.pt',map_location='cpu',weights_only=False)
cache=evaluate(model,rows,a.batch,lambda **v:print(json.dumps(v),flush=True),'native',feature=True)
cache['graph']=BundleGraph.read(run/'data'/a.dataset/'bi_train.txt',data.num_items).features(public_rows(rows))
out=ROOT/'generated/native'/a.dataset/a.condition;out.mkdir(parents=True,exist_ok=True)
torch.save(cache,out/f'B{a.batch}.pt')
print('Raw hits:',cache['hits'])
if a.condition in ['dual','repeat']:
    spec=importlib.util.spec_from_file_location('artifact_correction',ROOT/'src/correction/core.py')
    correction=importlib.util.module_from_spec(spec);spec.loader.exec_module(correction)
    RelationHead,head_features,predict,metrics=(getattr(correction,k) for k in ['RelationHead','head_features','predict','metrics'])
    key='without_dual' if a.condition=='repeat' else a.head_row
    record=json.loads((ROOT/'configs/experiments.json').read_text())[a.dataset][key]
    h=torch.load(a.head_checkpoint or ROOT/record['checkpoint'],map_location='cpu',weights_only=True)
    x=head_features(cache['features'],cache['graph'],cache['logits'],zero_graph=h.get('feature_mode')=='no_graph')
    x=(x-h['mean'])/h['std'];head=RelationHead(amplitude=h['amplitude']).eval();head.load_state_dict(h['state'])
    with torch.no_grad():score=torch.cat([head(x[i:i+256],cache['logits'][i:i+256]) for i in range(0,len(x),256)])
    result=metrics(cache['logits'],cache['labels'],predict(cache['logits'],score,record['gate']))
    (out/f'B{a.batch}_{key}.json').write_text(json.dumps(result,indent=2)+'\n');print(result)
