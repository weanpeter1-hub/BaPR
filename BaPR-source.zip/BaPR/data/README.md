# Data

Download the published item features and metadata from
https://huggingface.co/datasets/xhLiu/BundleConstruction and retain their original terms.
Set `--data-root` to the directory containing `pog`, `pog_dense`, `spotify`, and
`spotify_sparse`. Use the dataset identities in the included `count.json` files;
do not infer a renamed subset merely from similar folder names.

For each dataset this package includes the exact final query manifests, the
filtered `bi_train.txt`, the rebuilt bundle–item features, and `data_boundary.json`.
The latter lists the 1,024 base-training and 2,048 reserved correction bundle IDs.
`train_epoch_*.pt` are changing completion questions from the same base bundles.
The validation and test manifests retain the recorded 2,048 questions and ordered
ten-item candidate lists. Do not resample them when reproducing the tables.

`cache/<dataset>/{dual,repeat}` contains frozen logits, candidate features, graph
features and labels for correction training, validation and test. Here `train.pt`
means **correction-head training**, not the base-model training split.

Only the reserved correction manifests supervise the correction head and its
normalizer. Reserved bundle edges are excluded from the rebuilt bundle–item
representation and explicit co-occurrence graph. Published user–item CF and
multimodal item features are retained; this is not a claim that the reserved
items were unseen by every component.
